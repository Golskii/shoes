<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ctrl_Application extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        // Cek Login & Agency
        // cekSessionAgency($this->session->userdata('AGENCY'));
        // $this->agency = $this->session->userdata('AGENCY');
        // if (!empty($this->agency['NAMA_AGN'])) $admin = $this->agency['NAMA_AGN'];
        // else $admin = '';
        // $this->load->model('agency/Mdl_Agency', "mdl_agn");
        // $param = array('status' => 'agency');
        // $this->load->library('google', $param);
        // $this->load->library(array('session', 'facebook'));
        $this->page = array(
            // 'site'    => 'Triphalal.id',
            // 'admin'   => $admin,
            // 'plugins' => '',
            'data' => '',
            'navbar'  => (object) array(
                'left' => 'sales/navbar-left',
                'top'  => 'sales/navbar-top',
            ),
            // 'session' => $this->template,
        );
    }

    public function index()
    {
        $this->page['page'] = 'sales/home';
        $this->load->view('master-be', $this->page);
    }

    // public function addcust(){
    //     $this->page['page'] = 'sales/add-customer';
    //     $this->load->view('master-be', $this->page);
    // }

    // public function listcust(){
    //     $this->page['page'] = 'sales/list-customer';
    //     $this->load->view('master-be', $this->page);
    // }

    public function cust(){
        $this->page['page'] = 'sales/customer';
        $this->load->view('master-be', $this->page);
    }

    public function addnvc(){
        $this->page['page'] = 'sales/add-invoice';
        $this->load->view('master-be', $this->page);
    }

    public function editnvc(){
        $this->page['page'] = 'sales/edit-invoice';
        $this->load->view('master-be', $this->page);
    }

    public function listnvc()
    {
        $this->page['page'] = 'sales/list-invoice';
        $this->load->view('master-be', $this->page);
    }

    public function viewnvc()
    {
        $this->page['page'] = 'sales/view-invoice';
        $this->load->view('master-be', $this->page);
    }

    public function listnvcfnl()
    {
        $this->page['page'] = 'sales/list-invoice-final';
        $this->load->view('master-be', $this->page);
    }

    public function pendingpo()
    {
        $this->page['page'] = 'sales/po-pending';
        $this->load->view('master-be', $this->page);
    }

    public function processpo()
    {
        $this->page['page'] = 'sales/po-process';
        $this->load->view('master-be', $this->page);
    }

    public function completepo()
    {
        $this->page['page'] = 'sales/po-complete';
        $this->load->view('master-be', $this->page);
    }
}
