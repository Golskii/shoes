<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	function __construct()
	{
		parent::__construct();
		$this->load->model('main_models');
        $this->page = array(
            'data' => '',
            'navbar'  => (object) array(
                'left' => 'admin/navbar-left',
                'top'  => 'admin/navbar-top',
                'left_smr' => 'manajer/navbar-left',
                'left_sls' => 'sales/navbar-left',
                'left_prc' => 'purchase/navbar-left',
            ),
        );
	}

	function index()
	{
		$this->load->view('f_login');
	}

	function regis()
	{
		redirect('Login/index#signup');
	}

	function login_validasi()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('password', 'Email', 'required');
		if($this->form_validation->run())
		{
			$username = $this->input->post('username');
			$password = $this->input->post('password');
			// admin
		if($this->main_models->proses_login_user($username, $password))
		{
		//dashboard
		$this->load->model("invoice/queries_invoice");
        $this->load->model("queries");
        $this->load->model("customer/queries_customer");
        $this->page['dat_income'] = $this->queries_invoice->income_thismonth();
        //$this->page['dat_income'] = $this->queries->terbilang_angka($this->queries_invoice->income_thismonth());
        $this->page['dat_invoice'] = $this->queries_invoice->invoice_thismonth();
        $this->page['dat_po'] = $this->queries_invoice->po_thismonth(); 
        $dat_po = $this->queries_invoice->valueable_po();
        if($dat_po != null){
        	foreach ($dat_po as $po):
            	$po->bulan = $this->queries->bulan($po->PENAWARAN_TGL);
        	endforeach;
    	}
        $this->page['val_po'] = $dat_po;
        $dat_deadline = $this->queries->nearest_deadline();
        	foreach ($dat_deadline as $deadline):
            	$deadline->bulan = $this->queries->bulan($deadline->PO_DATELINE);
        	endforeach;
        $this->page['dat_deadline'] = $dat_deadline;
        $this->page['dat_customer'] = $this->queries_customer->customer_thismonth();
        $this->page['page'] = 'manajer/home';
        $this->load->view('master-be', $this->page);
        //dashboard
				}else{
					$this->session->set_flashdata('error', 'Invalid Username adn Password');
					redirect ('Login/index');		
				}
		}else{
			$this->index();
		}
	}

	function regis_validasi()
	{
		$this->load->library('form_validation');
		$this->form_validation->set_rules('username', 'Username', 'required');
		$this->form_validation->set_rules('fullname', 'Fullname', 'required');
		$this->form_validation->set_rules('email', 'Email', 'required');
		$this->form_validation->set_rules('alamat', 'Alamat', 'required');
		$this->form_validation->set_rules('telpon', 'No.Telpon', 'required');

		if($this->form_validation->run())
		{
			$akses = $this->input->post('akses');
			$data=$this->input->post();
			unset($data['insert']);
			unset($data['akses']);
			$this->load->model('main_models');

			if($akses == 2)
			{
				$this->main_models->proses_regis_sales($data);
				redirect ('Login/index');
			}else if($akses == 3)
			{
				$this->main_models->proses_regis_purchaser($data);
				redirect ('Login/index');
			}
		}
		else
		{
			$this->regis();
		}
	}

	function logout()
	{
		$this->session->sess_destroy();
		redirect ('Login/index');
	}

}

?>
