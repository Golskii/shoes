<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Ctrl_Application extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->page = array(
            'data' => '',
            'navbar'  => (object) array(
                'left' => 'admin/navbar-left',
                'top'  => 'admin/navbar-top',
                'left_smr' => 'manajer/navbar-left',
                'left_sls' => 'sales/navbar-left',
                'left_prc' => 'purchase/navbar-left',
            ),
        );
    }

    public function index()
    {
        if($this->session->userdata('login')){
            $this->dashboard();
        }else{
            $this->load->view('f_login');
        }
    }

    public function dashboard(){
        $this->load->model("invoice/queries_invoice");
        $this->load->model("queries");
        $this->load->model("customer/queries_customer");
        $this->page['dat_income'] = $this->queries_invoice->income_thismonth();
        //$this->page['dat_income'] = $this->queries->terbilang_angka($this->queries_invoice->income_thismonth());
        $this->page['dat_invoice'] = $this->queries_invoice->invoice_thismonth();
        $this->page['dat_po'] = $this->queries_invoice->po_thismonth(); 
        $dat_po = $this->queries_invoice->valueable_po();
        if($dat_po != null){
            foreach ($dat_po as $po):
                $po->bulan = $this->queries->bulan($po->PENAWARAN_TGL);
            endforeach;
        }
        $this->page['val_po'] = $dat_po;
        $dat_deadline = $this->queries->nearest_deadline();
            foreach ($dat_deadline as $deadline):
                $deadline->bulan = $this->queries->bulan($deadline->PO_DATELINE);
            endforeach;
        $this->page['dat_deadline'] = $dat_deadline;
        $this->page['dat_customer'] = $this->queries_customer->customer_thismonth();
        $this->page['page'] = 'manajer/home';
        $this->load->view('master-be', $this->page);
    }

    public function addsls(){
        $data = $this->input->post();
        $this->load->model("sales/queries_sales");
        $this->queries_sales->insert_sales($data);
        $this->sals();
    }

    public function sals(){
        if($this->session->userdata('login')){
            $this->load->model("sales/queries_sales");
            $dat_sales = $this->queries_sales->get_sales();
            $this->page['dat_sales'] = $dat_sales;
            $this->page['page'] = 'manajer/sales';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function formeditsls($SALES_KD){
        if($this->session->userdata('login')){
            $this->load->model("sales/queries_sales");
            $this->page['data'] = $this->queries_sales->get_sales_byKD($SALES_KD);
            $this->page['page'] = 'manajer/edit-sales';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function editsales(){
        $data = $this->input->post();
        $this->load->model("sales/queries_sales");
        $this->queries_sales->edit_sales($data);
        $this->sals();
    }

    public function hapussales($SALES_KD){
        $this->load->model("sales/queries_sales");
        $this->queries_sales->hapus_sales($SALES_KD);
        $this->sals();
    }

    public function addpurcs(){
        $data = $this->input->post();
        $this->load->model("purchase/queries_purchase");
        $this->queries_purchase->insert_purchase($data);
        $this->purchs();
    }

    public function purchs(){
        if($this->session->userdata('login')){
            $this->load->model("purchase/queries_purchase");
            $dat_purchase = $this->queries_purchase->get_purchase();
            $this->page['dat_purchase'] = $dat_purchase;
            $this->page['page'] = 'manajer/purchase';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function formeditprc($PURCHASE_KD){
        if($this->session->userdata('login')){
            $this->load->model("purchase/queries_purchase");
            $this->page['data'] = $this->queries_purchase->get_purchase_byKD($PURCHASE_KD);
            $this->page['page'] = 'manajer/edit-purchase';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function editpurchase(){
        $data = $this->input->post();
        $this->load->model("purchase/queries_purchase");
        $this->queries_purchase->edit_purchase($data);
        $this->purchs();
    }

    public function hapuspurchase($PURCHASE_KD){
        $this->load->model("purchase/queries_purchase");
        $this->queries_purchase->hapus_purchase($PURCHASE_KD);
        $this->purchs();
    }

    public function addcustomer(){
        $data = $this->input->post();
        $this->load->model("customer/queries_customer");
        $this->queries_customer->insert_customer($data);
        $this->custmr();
    }

    public function custmr(){
        if($this->session->userdata('login')){
            $this->load->model("customer/queries_customer");
            $dat_customer = $this->queries_customer->get_customer();
            $this->page['dat_customer'] = $dat_customer;
            $this->page['page'] = 'manajer/customer';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function formeditcst($CUSTOMER_KD){
        if($this->session->userdata('login')){
            $this->load->model("customer/queries_customer");
            $this->page['data'] = $this->queries_customer->get_customer_byKD($CUSTOMER_KD);
            $this->page['page'] = 'manajer/edit-customer';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function editcustomer(){
        $data = $this->input->post();
        $this->load->model("customer/queries_customer");
        $this->queries_customer->edit_customer($data);
        $this->custmr();
    }

    public function hapuscustomer($CUSTOMER_KD){
        $this->load->model("customer/queries_customer");
        $this->queries_customer->hapus_customer($CUSTOMER_KD);
        $this->custmr();
    }

    public function suggest_customer(){
        $this->load->model("customer/queries_customer");
        $dat_customer = $this->queries_customer->get_customer();
        $suggest = array();
        foreach ($dat_customer as $key) 
        {
            $kode[] = $key;
        }
            foreach ($kode as $data) 
            {
                $suggest[] = array(
                    "value" => htmlspecialchars_decode($data->CUSTOMER_NAMA),
                    "data" => $data->CUSTOMER_KD
                );
            }
        echo json_encode($suggest);
    }

    public function manjr(){
        if($this->session->userdata('login')){
            $this->load->model("manajer/queries_manajer");
            $dat_manajer = $this->queries_manajer->get_manajer();
            $this->page['dat_manajer'] = $dat_manajer;
            $this->page['page'] = 'manajer/manajer';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function formeditslm($MANAJER_KD){
        if($this->session->userdata('login')){
            $this->load->model("manajer/queries_manajer");
            $this->page['data'] = $this->queries_manajer->get_manajer_byKD($MANAJER_KD);
            $this->page['page'] = 'manajer/edit-manajer';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function editmanajer(){
        $data = $this->input->post();
        $this->load->model("manajer/queries_manajer");
        $this->queries_manajer->edit_manajer($data);
        $this->manjr();
    }

    public function hapusmanajer($MANAJER_KD){
        $this->load->model("manajer/queries_manajer");
        $this->queries_manajer->hapus_manajer($MANAJER_KD);
        $this->manjr();
    }

    public function addnvc(){
        if($this->session->userdata('login')){
            $this->load->model("sales/queries_sales");
            $this->load->model("customer/queries_customer");
            $dat_customer = $this->queries_customer->get_customer();
            $dat_sales    = $this->queries_sales->get_sales();
            $this->page['dat_customer'] = $dat_customer;
            $this->page['dat_sales']    = $dat_sales;
            $this->page['page'] = 'manajer/add-invoice';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function post_invoice(){
            $data = $this->input->post();
            $this->load->model("queries");
            $this->load->model("invoice/queries_invoice");
            $this->load->model("sales/queries_sales");
            // Insert sw_motor
            $data_motor = array(
                'MOTOR_HP' => $this->input->post('MOTOR_HP'),
                'MOTOR_NAMA' => $this->input->post('MOTOR_NAMA'),
                'MOTOR_BRAND' => $this->input->post('MOTOR_BRAND'),
                'MOTOR_KVA' => $this->input->post('MOTOR_KVA'),
                'MOTOR_KW' => $this->input->post('MOTOR_KW'),
                'MOTOR_VOLTS' => $this->input->post('MOTOR_VOLTS'),
                'MOTOR_VOLTS_EX' => $this->input->post('MOTOR_VOLTS_EX'),
                'MOTOR_FRAME' => $this->input->post('MOTOR_FRAME'),
                'MOTOR_HZ' => $this->input->post('MOTOR_HZ'),
                'MOTOR_MODEL' => $this->input->post('MOTOR_MODEL'),
                'MOTOR_RPM' => $this->input->post('MOTOR_RPM'),
                'MOTOR_PH' => $this->input->post('MOTOR_PH'),
                'MOTOR_VOLTSS' => $this->input->post('MOTOR_VOLTSS'),
                'MOTOR_TIPE' => $this->input->post('MOTOR_TIPE'),
                'MOTOR_AMPS' => $this->input->post('MOTOR_AMPS'),
                'MOTOR_SNO' => $this->input->post('MOTOR_SNO'),
                'MOTOR_INSUL_CL' => $this->input->post('MOTOR_INSUL_CL'),
                'MOTOR_BEARING_DE' => $this->input->post('MOTOR_BEARING_DE'),
                'MOTOR_BEARING_NDE' => $this->input->post('MOTOR_BEARING_NDE'),
                'MOTOR_BEARING_BY' => $this->input->post('MOTOR_BEARING_BY'),
                'MOTOR_REQUISITOR' => $this->input->post('MOTOR_REQUISITOR'),
                'MOTOR_REF_NO_WO' => $this->input->post('MOTOR_REF_NO_WO')
            );
            $this->queries->insert_motor($data_motor);
            // Insert sw_workscope
            $data_workscope = array(
                'Site_Work' => $this->input->post('WORK_SITE'),
                'Initial_Testing' => $this->input->post('WORK_INITIAL'),
                'Disassembly' => $this->input->post('WORK_DISASSEMBLY'),
                'Reassemble' => $this->input->post('WORK_REASSEMBLE'),
                'Steam_/_Chemical_Clean' => $this->input->post('WORK_STEAM'),
                'Bake_Windings' => $this->input->post('WORK_BAKE_WINDINGS'),
                'Varnish_Treatment' => $this->input->post('WORK_VARNISH'),
                'Bake_and_Cure' => $this->input->post('WORK_BAKE_CURE'),
                'Final_Test_-_No_Load' => $this->input->post('WORK_FINAL')
            );
            $this->queries->insert_workscope($data_workscope);
            // Insert sw_penawaran
            $dat_user = $this->queries_sales->get_sales_byNAMA($data);
            $dat_motor = $this->queries->get_last_motor();
            $dat_work = $this->queries->get_last_workscope();
            if(count($dat_user)){
                foreach($dat_user as $user):
                    $user_kd = $user->USER_KD;
                endforeach;
            }else{
                $this->addnvc();
            }
            foreach($dat_motor as $motor):
                $motor_kd = $motor->MOTOR_KD;
            endforeach;
            foreach($dat_work as $work):
                $work_kd = $work->WORK_KD;
            endforeach;
            $penawaran_kd = $this->queries_invoice->autonumber($data['PENAWARAN_TGL'], $data['PENAWARAN_KATEGORI']);
            $data_penawaran = array(
                'PENAWARAN_KATEGORI' => $this->input->post('PENAWARAN_KATEGORI'),
                'PENAWARAN_TGL' => $this->input->post('PENAWARAN_TGL'),
                'PENAWARAN_NOMINAL' => $this->input->post('PENAWARAN_NOMINAL'),
                'PENAWARAN_STATUS_AKTIF' => 1,
                'CUSTOMER_KD' => $this->input->post('CUSTOMER_KD'),
                'PO_KD' => $this->input->post('PO_KD'),
                'PENAWARAN_KD' => $penawaran_kd,
                'USER_KD' => $user_kd,
                'MOTOR_KD' => $motor_kd,
                'WORK_KD' => $work_kd
            );
            $this->queries_invoice->insert_invoice($data_penawaran);
            // Insert sw_perbaikan
            $data_harga = array(
                    'HARGA_KD' => ''
                );
            $this->queries->insert_harga($data_harga);
            $dat_harga = $this->queries->get_last_harga();
            foreach($dat_harga as $harga):
                $harga_kd = $harga->HARGA_KD;
            endforeach;
            if($this->input->post('PERBAIKAN_NAMA')){
                $data_perbaikan = array(
                'PERBAIKAN_KD' => '',
                'PENAWARAN_KD' => $penawaran_kd,
                'HARGA_KD' => $harga->HARGA_KD,
                'PERBAIKAN_NAMA' => $this->input->post('PERBAIKAN_NAMA')
                );
                $this->queries->insert_perbaikan($data_perbaikan);
            }
            // Insert sw_additional
            if($this->input->post('WORK_DYNAMIC') != null){
                
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_DYNAMIC'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_SKIN') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_SKIN'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_CARBON_BRUSHES') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_CARBON_BRUSHES'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_REBUSH_HOUSING') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_REBUSH_HOUSING'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_REPAIR_JOURNAL') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_REPAIR_JOURNAL'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_REBBIT_SLEEVE') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_REBBIT_SLEEVE'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_LABYRINTH') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_LABYRINTH'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }
            $bearing_by = $this->input->post('MOTOR_BEARING_BY');
            if($bearing_by = 1){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => 'Bearing DE',
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);

                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => 'Bearing NDE',
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }
            // Insert custom
            if($this->input->post('CUSTOM_NAMA[0]') != ""){
                $data_add = $this->input->post('CUSTOM_NAMA');
                foreach($data_add as $custom):
                    $data_harga = array(
                    'HARGA_KD' => ''
                );
                    $this->queries->insert_harga($data_harga);
                    $dat_harga = $this->queries->get_last_harga();
                    foreach($dat_harga as $harga):
                        $harga_kd = $harga->HARGA_KD;
                    endforeach;
                    $data_custom = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'CUSTOM_NAMA' => $custom,
                        'CUSTOM_KD' => ''
                    );
                    $this->queries->insert_custom($data_custom);
                endforeach;
            }   
            $this->listnvc();
    }
    
    public function editnvc($PENAWARAN_KD){
        if($this->session->userdata('login')){
             $this->load->model("customer/queries_customer");
            $dat_customer = $this->queries_customer->get_customer();
            $this->page['dat_customer'] = $dat_customer;
            $this->load->model("invoice/queries_invoice");
            $data = $this->queries_invoice->get_data_update($PENAWARAN_KD);
            // print_r($data);
            // die();
            $adtData = $this->queries_invoice->get_data_update_adt($PENAWARAN_KD);
            //print_r($adtData);
            $this->page['adtData'] = $adtData;
            $this->page['data'] = $data;
            $this->page['page'] = 'manajer/edit-invoice';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function updatenvc(){
        if($this->session->userdata('login')){
            $data = $this->input->post();
            $this->load->model("queries");
            $this->load->model("invoice/queries_invoice");
            $this->load->model("sales/queries_sales");

            // Update sw_motor
            $motor_kd = $this->input->post('MOTOR_KD');
            $data_motor = array(
                'MOTOR_HP' => $this->input->post('MOTOR_HP'),
                'MOTOR_NAMA' => $this->input->post('MOTOR_NAMA'),
                'MOTOR_BRAND' => $this->input->post('MOTOR_BRAND'),
                'MOTOR_KVA' => $this->input->post('MOTOR_KVA'),
                'MOTOR_KW' => $this->input->post('MOTOR_KW'),
                'MOTOR_VOLTS' => $this->input->post('MOTOR_VOLTS'),
                'MOTOR_VOLTS_EX' => $this->input->post('MOTOR_VOLTS_EX'),
                'MOTOR_FRAME' => $this->input->post('MOTOR_FRAME'),
                'MOTOR_HZ' => $this->input->post('MOTOR_HZ'),
                'MOTOR_MODEL' => $this->input->post('MOTOR_MODEL'),
                'MOTOR_RPM' => $this->input->post('MOTOR_RPM'),
                'MOTOR_PH' => $this->input->post('MOTOR_PH'),
                'MOTOR_VOLTSS' => $this->input->post('MOTOR_VOLTSS'),
                'MOTOR_TIPE' => $this->input->post('MOTOR_TIPE'),
                'MOTOR_AMPS' => $this->input->post('MOTOR_AMPS'),
                'MOTOR_SNO' => $this->input->post('MOTOR_SNO'),
                'MOTOR_INSUL_CL' => $this->input->post('MOTOR_INSUL_CL'),
                'MOTOR_BEARING_DE' => $this->input->post('MOTOR_BEARING_DE'),
                'MOTOR_BEARING_NDE' => $this->input->post('MOTOR_BEARING_NDE'),
                'MOTOR_BEARING_BY' => $this->input->post('MOTOR_BEARING_BY'),
                'MOTOR_REQUISITOR' => $this->input->post('MOTOR_REQUISITOR'),
                'MOTOR_REF_NO_WO' => $this->input->post('MOTOR_REF_NO_WO')
            );
            $this->queries->update_motor($data_motor, $motor_kd);

            // Update sw_workscope
            $work_kd = $this->input->post('WORK_KD');
            $data_workscope = array(
                'Site_Work' => $this->input->post('WORK_SITE'),
                'Initial_Testing' => $this->input->post('WORK_INITIAL'),
                'Disassembly' => $this->input->post('WORK_DISASSEMBLY'),
                'Reassemble' => $this->input->post('WORK_REASSEMBLE'),
                'Steam_/_Chemical_Clean' => $this->input->post('WORK_STEAM'),
                'Bake_Windings' => $this->input->post('WORK_BAKE_WINDINGS'),
                'Varnish_Treatment' => $this->input->post('WORK_VARNISH'),
                'Bake_and_Cure' => $this->input->post('WORK_BAKE_CURE'),
                'Final_Test_-_No_Load' => $this->input->post('WORK_FINAL')
            );
            $this->queries->update_workscope($data_workscope, $work_kd);

            // Update sw_penawaran
            $dat_user = $this->queries_sales->get_sales_byNAMA($data);
            // $dat_motor = $this->queries->get_last_motor();
            // $dat_work = $this->queries->get_last_workscope();
            if(count($dat_user)){
                foreach($dat_user as $user):
                    $user_kd = $user->USER_KD;
                endforeach;
            }else{
                $this->editnvc($this->input->post('PENAWARAN_KD'));
            }
            // foreach($dat_work as $work):
            //         $work_kd = $work->WORK_KD;
            // endforeach;
            $penawaran_kd = $this->input->post('PENAWARAN_KD');
            $data_penawaran = array(
                'PENAWARAN_KATEGORI' => $this->input->post('PENAWARAN_KATEGORI'),
                'PENAWARAN_TGL' => $this->input->post('PENAWARAN_TGL'),
                'PENAWARAN_NOMINAL' => $this->input->post('PENAWARAN_NOMINAL'),
                'PENAWARAN_STATUS_AKTIF' => 1,
                'CUSTOMER_KD' => $this->input->post('CUSTOMER_KD'),
                'PO_KD' => $this->input->post('PO_KD'),
                'PENAWARAN_KD' => $penawaran_kd,
                'USER_KD' => $user_kd,
                'MOTOR_KD' => $motor_kd,
                'WORK_KD' => $work_kd
            );
            $this->queries_invoice->update_invoice($data_penawaran, $penawaran_kd);

            // Update sw_perbaikan
            $perbaikan_kd = $this->input->post('PERBAIKAN_KD');
            if($this->input->post('PERBAIKAN_NAMA')){
                $data_perbaikan = array(
                'PENAWARAN_KD' => $penawaran_kd,
                'PERBAIKAN_NAMA' => $this->input->post('PERBAIKAN_NAMA')
                );
                $this->queries->update_perbaikan($data_perbaikan, $penawaran_kd );
            }

            // update sw_additional
            $this->queries->delete_additional($penawaran_kd);
            // echo $this->db->last_query();die();
            if($this->input->post('WORK_DYNAMIC') != null){
                
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_DYNAMIC'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_SKIN') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_SKIN'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_CARBON_BRUSHES') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_CARBON_BRUSHES'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_REBUSH_HOUSING') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_REBUSH_HOUSING'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_REPAIR_JOURNAL') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_REPAIR_JOURNAL'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_REBBIT_SLEEVE') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_REBBIT_SLEEVE'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }if($this->input->post('WORK_LABYRINTH') != null){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => $this->input->post('WORK_LABYRINTH'),
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }
            $bearing_by = $this->input->post('MOTOR_BEARING_BY');
            if($bearing_by == 1){
                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => 'Bearing DE',
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);

                $data_harga = array(
                    'HARGA_KD' => ''
                );
                $this->queries->insert_harga($data_harga);
                $dat_harga = $this->queries->get_last_harga();
                foreach($dat_harga as $harga):
                    $harga_kd = $harga->HARGA_KD;
                endforeach;
                $data_additional = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'ADDITIONAL_NAMA' => 'Bearing NDE',
                        'ADDITIONAL_KD' => ''
                );
                $this->queries->insert_additional($data_additional);
            }
            // Update custom
            $this->queries->delete_custom($penawaran_kd);
            if($this->input->post('CUSTOM_NAMA[0]') != ""){
                $data_add = $this->input->post('CUSTOM_NAMA');
                foreach($data_add as $custom):
                    $data_harga = array(
                    'HARGA_KD' => ''
                );
                    $this->queries->insert_harga($data_harga);
                    $dat_harga = $this->queries->get_last_harga();
                    foreach($dat_harga as $harga):
                        $harga_kd = $harga->HARGA_KD;
                    endforeach;
                    $data_custom = array(
                        'PENAWARAN_KD' => $penawaran_kd,
                        'HARGA_KD' => $harga->HARGA_KD,
                        'CUSTOM_NAMA' => $custom,
                        'CUSTOM_KD' => ''
                    );
                    $this->queries->insert_custom($data_custom);
                endforeach;
            }   
            $this->listnvc();
        }else{
            $this->load->view('f_login');
        }
    }

    public function savenvc(){
        if($this->session->userdata('login')){
            $this->load->model("queries");
            $this->load->model("invoice/queries_invoice");
            $data_add = $this->input->post();
            $jumlah = $this->input->post("jumlah");
            $penawaran = $this->input->post("penawaran");
            for ($i=1; $i <= $jumlah; $i++) { 
                $kode = $this->input->post("kode_".$i);
                $data = array(
                        'HARGA_MATERIAL_PR' => $this->input->post("HARGA_MATERIAL_PR_".$kode),
                        'HARGA_MATERIAL_SM' => $this->input->post("HARGA_MATERIAL_SM_".$kode),
                        'HARGA_JASA_PR' => $this->input->post("HARGA_JASA_PR_".$kode),
                        'HARGA_JASA_SM' => $this->input->post("HARGA_JASA_SM_".$kode)
                );
                $this->queries->update_harga($kode,$data);
            }
            $cek = $this->input->post("total_sm");
            if($cek != 0 || $cek != null){
                $data_nominal = array(
                        'PENAWARAN_NOMINAL' => $this->input->post("total_sm")
                );
                $this->queries_invoice->update_nominal($penawaran,$data_nominal);
            }else{
                $this->listnvc();    
            }
            $this->listnvc();
        }else{
            $this->load->view('f_login');
        }
    }

    public function listnvc()
    {
        if($this->session->userdata('login')){
            $this->load->model("invoice/queries_invoice");
            $dat_invoice = $this->queries_invoice->get_invoice_awal();
            $this->page['dat_invoice'] = $dat_invoice;
            $this->load->model("customer/queries_customer");
            $dat_customer = $this->queries_customer->list_customer();
            $this->page['dat_customer'] = $dat_customer;
            $this->load->model("queries");
            $dat_motor = $this->queries->get_motor();
            $this->page['dat_motor'] = $dat_motor;
            $this->page['page'] = 'manajer/list-invoice';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function viewnvc($PENAWARAN_KD)
    {
        if($this->session->userdata('login')){
            $this->load->model("invoice/queries_invoice");
            $dat_invoice = $this->queries_invoice->get_invoice_byKD($PENAWARAN_KD);
            foreach($dat_invoice as $invoice):
                $motor_kd = $invoice->MOTOR_KD;
                $customer_kd = $invoice->CUSTOMER_KD;
                $work_kd = $invoice->WORK_KD;
                $user_kd = $invoice->USER_KD;
            endforeach;
            $this->page['dat_penawaran'] = $dat_invoice;
            $this->load->model("customer/queries_customer");
            $this->page['dat_customer'] = $this->queries_customer->get_customer_byKD($customer_kd);
            $this->load->model("sales/queries_sales");
            $this->page['dat_sales'] = $this->queries_sales->get_sales_byKD($user_kd);
            $this->load->model("queries");
            $this->page['dat_work'] = $this->queries->get_work_byKD($work_kd);
            $this->page['dat_motor'] = $this->queries->get_motor_byKD($motor_kd);
            $this->page['dat_custom'] = $this->queries->get_harga_cust_byPENAWARAN_KD($PENAWARAN_KD);
            $this->page['dat_additional'] = $this->queries->get_harga_add_byPENAWARAN_KD($PENAWARAN_KD);
            $this->page['dat_view_list_workscope'] = $this->queries_invoice->get_view_list_workscope();
            $this->page['page'] = 'manajer/view-invoice';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function viewnvcfnl($PENAWARAN_KD)
    {
        if($this->session->userdata('login')){
            $this->load->model("invoice/queries_invoice");
            $dat_invoice = $this->queries_invoice->get_invoice_byKD($PENAWARAN_KD);
            foreach($dat_invoice as $invoice):
                $motor_kd = $invoice->MOTOR_KD;
                $customer_kd = $invoice->CUSTOMER_KD;
                $work_kd = $invoice->WORK_KD;
                $user_kd = $invoice->USER_KD;
            endforeach;
            $this->page['dat_penawaran'] = $dat_invoice;
            $this->load->model("customer/queries_customer");
            $this->page['dat_customer'] = $this->queries_customer->get_customer_byKD($customer_kd);
            $this->load->model("sales/queries_sales");
            $this->page['dat_sales'] = $this->queries_sales->get_sales_byKD($user_kd);
            $this->load->model("queries");
            $this->page['dat_work'] = $this->queries->get_work_byKD($work_kd);
            $this->page['dat_motor'] = $this->queries->get_motor_byKD($motor_kd);
            $dat_custom = $this->queries->get_harga_cust_byPENAWARAN_KD($PENAWARAN_KD);
            $dat_additional = $this->queries->get_harga_add_byPENAWARAN_KD($PENAWARAN_KD);

            $materialTotalCustom = 0;
            $serviceTotalCustom = 0;
            if ($dat_custom != null) {
                foreach ($dat_custom as $key => $value) {
                    $materialTotalCustom += $value->HARGA_MATERIAL_SM;
                    $serviceTotalCustom += $value->HARGA_JASA_SM;
                }
            }
            $materialTotalAdt = 0;
            $serviceTotalAdt = 0;
            if ($dat_additional != null) {
                foreach ($dat_additional as $key => $value) {
                    $materialTotalAdt += $value->HARGA_MATERIAL_SM;
                    $serviceTotalAdt += $value->HARGA_JASA_SM;
                }
            }
            // echo $materialTotalCustom + $materialTotalAdt;

            $this->page['dat_custom'] = $dat_custom;
            $this->page['dat_material_total'] = $materialTotalCustom + $materialTotalAdt;
            $this->page['dat_service_total'] = $serviceTotalCustom + $serviceTotalAdt;
            $this->page['dat_additional'] = $dat_additional;
            $this->page['dat_view_list_workscope'] = $this->queries_invoice->get_view_list_workscope();
            $this->page['page'] = 'manajer/view-invoice-final';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function listnvcfnl()
    {
        if($this->session->userdata('login')){
            $this->load->model("invoice/queries_invoice");
            $dat_invoice = $this->queries_invoice->get_invoice_akhir();
            $this->page['dat_invoice'] = $dat_invoice;
            $this->load->model("customer/queries_customer");
            $dat_customer = $this->queries_customer->list_customer();
            $this->page['dat_customer'] = $dat_customer;
            $this->load->model("queries");
            $dat_motor = $this->queries->get_motor();
            $this->page['dat_motor'] = $dat_motor;
            $this->page['page'] = 'manajer/list-invoice-final';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function savepo($kode_penawaran, $kode_po)
    {
        $kode = $this->input->post('kode_penawaran');
        $data_po = array(
                'PO_KD' => $kode_po,
                'PO_TGL' => date("Y-m-d"),
                'PO_START' => '',
                'PO_END' => '',
                'PO_DATELINE' => '',
                'STATUS' => ''
            );
        $this->load->model("invoice/queries_invoice");
        $this->queries_invoice->insert_po($data_po);
        $last_po = $this->queries_invoice->get_last_po();
        foreach($last_po as $po):
                $po_kd = $po->PO_KD;
        endforeach;
        $data = array(
            'PO_KD' => $po_kd
            );
        $this->queries_invoice->update_penawaran_po($kode,$data);
    }

    public function pendingpo()
    {
        if($this->session->userdata('login')){
            $this->load->model("invoice/queries_invoice");
            $dat_order = $this->queries_invoice->get_po_pending();
            $this->page['dat_order'] = $dat_order;
            $this->page['page'] = 'manajer/po-pending';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function processpo()
    {
        if($this->session->userdata('login')){
            $this->load->model("invoice/queries_invoice");
            $dat_order = $this->queries_invoice->get_po_process();
            $this->page['dat_order'] = $dat_order;
            $this->page['page'] = 'manajer/po-process';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function completepo()
    {
        if($this->session->userdata('login')){
            $this->load->model("invoice/queries_invoice");
            $dat_order = $this->queries_invoice->get_po_complete();
            $this->page['dat_order'] = $dat_order;
            $this->page['page'] = 'manajer/po-complete';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function viewpendingpo($PO_KD=null)
    {
        if($this->session->userdata('login')){
            if ($PO_KD != null) {
                $this->load->model("invoice/queries_invoice");
                $dat_order = $this->queries_invoice->get_detail_po($PO_KD)[0];
                $dat_order->ADDITIONAL = $this->queries_invoice->get_additional($dat_order->PENAWARAN_KD);
                $dat_order->CUSTOM = $this->queries_invoice->get_custom($dat_order->PENAWARAN_KD);
                $dat_order->PERBAIKAN = $this->queries_invoice->get_perbaikan($dat_order->PENAWARAN_KD);

                $this->load->model("queries");
                $dat_order->WORK = $this->queries->get_work_byKD($dat_order->WORK_KD)[0];
                $dat_order->MOTOR = $this->queries->get_motor_byKD($dat_order->MOTOR_KD)[0];

                $materialTotalCustom = 0;
                $serviceTotalCustom = 0;
                if ($dat_order != null) {
                    foreach ((array)$dat_order->CUSTOM as $key =>$value){

                        $materialTotalCustom += $value['HARGA_MATERIAL_SM'];
                        $serviceTotalCustom += $value['HARGA_JASA_SM'];
                    }
                }
                $materialTotalAdt = 0;
                $serviceTotalAdt = 0;
                if ($dat_order != null) {
                    foreach ((array)$dat_order->ADDITIONAL as $key =>$value) {
                        $materialTotalAdt += $value['HARGA_MATERIAL_SM'];
                        $serviceTotalAdt += $value['HARGA_JASA_SM'];
                    }
                }

                $this->page['dat_material_total'] = $materialTotalCustom + $materialTotalAdt;
                $this->page['dat_service_total'] = $serviceTotalCustom + $serviceTotalAdt;


                $this->page['dat_order'] = $dat_order;
                $this->page['page'] = 'manajer/view-po-pending';
                $this->load->view('master-be', $this->page);
            }else{
                redirect(site_url('master-manajer/pendingpo/'));
            }
        }else{
            $this->load->view('f_login');
        }
    }

    public function viewprocesspo($PO_KD=null)
    {
        if($this->session->userdata('login')){
            if ($PO_KD != null) {
                $this->load->model("invoice/queries_invoice");
                $dat_order = $this->queries_invoice->get_detail_po($PO_KD)[0];
                $dat_order->ADDITIONAL = $this->queries_invoice->get_additional($dat_order->PENAWARAN_KD);
                $dat_order->CUSTOM = $this->queries_invoice->get_custom($dat_order->PENAWARAN_KD);
                $dat_order->PERBAIKAN = $this->queries_invoice->get_perbaikan($dat_order->PENAWARAN_KD);

                $this->load->model("queries");
                $dat_order->WORK = $this->queries->get_work_byKD($dat_order->WORK_KD)[0];
                $dat_order->MOTOR = $this->queries->get_motor_byKD($dat_order->MOTOR_KD)[0];

                $materialTotalCustom = 0;
                $serviceTotalCustom = 0;
                if ($dat_order != null) {
                    foreach ((array)$dat_order->CUSTOM as $key =>$value){

                        $materialTotalCustom += $value['HARGA_MATERIAL_SM'];
                        $serviceTotalCustom += $value['HARGA_JASA_SM'];
                    }
                }
                $materialTotalAdt = 0;
                $serviceTotalAdt = 0;
                if ($dat_order != null) {
                    foreach ((array)$dat_order->ADDITIONAL as $key =>$value) {
                        $materialTotalAdt += $value['HARGA_MATERIAL_SM'];
                        $serviceTotalAdt += $value['HARGA_JASA_SM'];
                    }
                }

                $this->page['dat_material_total'] = $materialTotalCustom + $materialTotalAdt;
                $this->page['dat_service_total'] = $serviceTotalCustom + $serviceTotalAdt;


                $this->page['dat_order'] = $dat_order;
                $this->page['page'] = 'manajer/view-po-process';
                $this->load->view('master-be', $this->page);
            }else{
                redirect(site_url('master-manajer/processpo/'));
            }
        }else{
            $this->load->view('f_login');
        }
    }

    public function viewcompletepo($PO_KD=null)
    {
        if($this->session->userdata('login')){
            if ($PO_KD != null) {
                $this->load->model("invoice/queries_invoice");
                $dat_order = $this->queries_invoice->get_detail_po($PO_KD)[0];
                $dat_order->ADDITIONAL = $this->queries_invoice->get_additional($dat_order->PENAWARAN_KD);
                $dat_order->CUSTOM = $this->queries_invoice->get_custom($dat_order->PENAWARAN_KD);
                $dat_order->PERBAIKAN = $this->queries_invoice->get_perbaikan($dat_order->PENAWARAN_KD);

                $this->load->model("queries");
                $dat_order->WORK = $this->queries->get_work_byKD($dat_order->WORK_KD)[0];
                $dat_order->MOTOR = $this->queries->get_motor_byKD($dat_order->MOTOR_KD)[0];

                
                $materialTotalCustom = 0;
                $serviceTotalCustom = 0;
                if ($dat_order != null) {
                    foreach ((array)$dat_order->CUSTOM as $key =>$value){

                        $materialTotalCustom += $value['HARGA_MATERIAL_SM'];
                        $serviceTotalCustom += $value['HARGA_JASA_SM'];
                    }
                }
                $materialTotalAdt = 0;
                $serviceTotalAdt = 0;
                if ($dat_order != null) {
                    foreach ((array)$dat_order->ADDITIONAL as $key =>$value) {
                        $materialTotalAdt += $value['HARGA_MATERIAL_SM'];
                        $serviceTotalAdt += $value['HARGA_JASA_SM'];
                    }
                }

                $this->page['dat_material_total'] = $materialTotalCustom + $materialTotalAdt;
                $this->page['dat_service_total'] = $serviceTotalCustom + $serviceTotalAdt;

                $this->page['dat_order'] = $dat_order;
                $this->page['page'] = 'manajer/view-po-complete';
                $this->load->view('master-be', $this->page);
            }else{
                redirect(site_url('master-manajer/completepo/'));
            }
        }else{
            $this->load->view('f_login');
        }
    }
    public function aksi_upload(){        
        $nama = $_FILES['file']['name'];
        $x = explode('.', $nama);
        $extensi = strtolower(end($x));
        $kode = $this->input->post('kode_penawaran');
        $nama_baru = $kode." .".$extensi;
        $kode_po = $this->input->post('PO_KD');

        $config['file_name'] = $nama_baru;
        $config['upload_path'] = './berkas/';
        $config['allowed_types'] = 'pdf|doc|docx';
        $this->load->library('upload', $config);
        $this->upload->initialize($config);

        if ( ! $this->upload->do_upload('file')){
            
            $error = array('error' => $this->upload->display_errors());
            $this->session->set_flashdata('pesan', 'Submit Failed');
            $this->viewnvcfnl($kode);
        }else{
            $data = array('upload_data' => $this->upload->data());
            $this->session->set_flashdata('pesan', 'Submit Success');
            $this->savepo($kode, $kode_po);
            $this->viewnvcfnl($kode);
        }
    }

    function pdf($PENAWARAN_KD) { 
        define('FPDF_FONTPATH',$this->config->item('fonts_path'));
        // ambil data untuk pdf
            $this->load->model("invoice/queries_invoice");
            $dat_invoice = $this->queries_invoice->get_invoice_byKD($PENAWARAN_KD);
            foreach($dat_invoice as $invoice):
                $motor_kd = $invoice->MOTOR_KD;
                $customer_kd = $invoice->CUSTOMER_KD;
                $work_kd = $invoice->WORK_KD;
                $user_kd = $invoice->USER_KD;
            endforeach;
            $this->page['dat_penawaran'] = $invoice;
            $this->load->model("customer/queries_customer");
            $this->page['dat_customer'] = $this->queries_customer->get_customer_byKD($customer_kd);
            $this->load->model("sales/queries_sales");
            $this->page['dat_sales'] = $this->queries_sales->get_sales_byKD($user_kd);
            $this->load->model("queries");
            $this->page['dat_work'] = $this->queries->get_work_byKD($work_kd);
            $dat_motor = $this->queries->get_motor_byKD($motor_kd);
            foreach($dat_motor as $motor):
            endforeach;
            $this->page['dat_motor'] = $motor;
            $dat_perbaikan = $this->queries->get_perbaikan_byPENAWARAN_KD($PENAWARAN_KD);
            foreach($dat_perbaikan as $perbaikan):
            endforeach;
            $this->page['dat_perbaikan'] = $perbaikan;
            $dat_custom = $this->queries->get_harga_cust_byPENAWARAN_KD($PENAWARAN_KD);
            $dat_additional = $this->queries->get_harga_add_byPENAWARAN_KD($PENAWARAN_KD);

            $materialTotalCustom = 0;
            $serviceTotalCustom = 0;
            if ($dat_custom != null) {
                foreach ($dat_custom as $key => $value) {
                    $materialTotalCustom += $value->HARGA_MATERIAL_SM;
                    $serviceTotalCustom += $value->HARGA_JASA_SM;
                }
            }
            $materialTotalAdt = 0;
            $serviceTotalAdt = 0;
            if ($dat_additional != null) {
                foreach ($dat_additional as $key => $value) {
                    $materialTotalAdt += $value->HARGA_MATERIAL_SM;
                    $serviceTotalAdt += $value->HARGA_JASA_SM;
                }
            }

            $this->page['dat_custom'] = $dat_custom;
            $this->page['dat_material_total'] = $materialTotalCustom + $materialTotalAdt;
            $this->page['dat_service_total'] = $serviceTotalCustom + $serviceTotalAdt;
            $this->page['dat_terbilang'] = $this->queries->terbilang($invoice->PENAWARAN_NOMINAL);
            $this->page['dat_additional'] = $dat_additional;
            $this->page['dat_view_list_workscope'] = $this->queries_invoice->get_view_list_workscope();
        $this->load->view('manajer/pdf_invoice_final', $this->page);
    }

    public function report()
    {
        if($this->session->userdata('login')){
            
            $this->page['page'] = 'manajer/report';
            $this->load->view('master-be', $this->page);
        }else{
            $this->load->view('f_login');
        }
    }

    public function test()
    {   
       $date = date("Y-m-d");
       echo $date;
    }

}
