<div class="right_col" role="main">
  <div class="">
    <div class="row top_tiles">
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <!-- Total customer yang mengirim MoU bulan ini -->
          <div class="icon"><i class="fa fa-user"></i></div>
          <div class="count"><?php if($dat_customer != null){ echo $dat_customer;
            }else{
            echo "0";
            } ?></div>
          <h3>Customers</h3>
          <p>Total customer this month</p> 
        </div>
      </div>
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <!-- Total nominal completed PO yg selesai bulan ini -->
          <div class="icon"><i class="fa fa-database"></i></div>
          <div class="count">Rp <?php if($dat_income != null){ echo $dat_income;
            }else{
            echo "0";
            } ?></div>
          <h3>Income</h3>
          <p>Total income this month</p>
        </div>
      </div>
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <!-- Total seluruh invoice gagal maupun menunggu MoU di bulan ini -->
          <div class="icon"><i class="fa fa-edit"></i></div>
          <div class="count"><?php if($dat_invoice != null){ echo $dat_invoice;
            }else{
            echo "0";
            } ?></div>
          <h3>Invoice</h3>
          <p>Total invoice this month</p>
        </div>
      </div>
      <div class="animated flipInY col-lg-3 col-md-3 col-sm-6 col-xs-12">
        <div class="tile-stats">
          <!-- Total PO (pending+process+completed) di bulan ini-->
          <div class="icon"><i class="fa fa-file-text-o"></i></div>
          <div class="count"><?php if($dat_po != null){ 
            echo $dat_po;
            }else{
            echo "0";
            } ?></div>
          <h3>Purchase Order</h3>
          <p>Total Purchase Order this month</p>
        </div>
      </div>
    </div>
    
    <div class="row">
      <div class="col-md-4">
        <div class="x_panel">
          <div class="x_title">
            <h2>Nearest Deadline <small>This Month</small></h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Settings 1</a>
                  </li>
                  <li><a href="#">Settings 2</a>
                  </li>
                </ul>
              </li>
              <li><a class="close-link"><i class="fa fa-close"></i></a>
              </li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
          <?php if($dat_deadline != null){ foreach ($dat_deadline as $dat_deadline):?>
            <article class="media event">
              <a class="pull-left date">
                <p class="month"><?php echo $dat_deadline->bulan; ?></p>
                <p class="day"><?php echo substr($dat_deadline->PO_DATELINE,8,2); ?></p>
              </a>
              <div class="media-body">
                <a class="title"><?php echo $dat_deadline->CUSTOMER_NAMA ?></a>
                <!-- Jika 18-04-01-002 di klik maka menuju page view detail proses PO dengan job number tersebut -->
                <p>Job Number: <a href="#"><strong><?php echo $dat_deadline->PENAWARAN_KD ?></strong></a></p> 
                <p>Rp <?php echo $dat_deadline->PENAWARAN_NOMINAL ?> (
                <?php 
                  $end_date = new DateTime($dat_deadline->PO_DATELINE);
                  $current_date = new DateTime(date('Y-m-d'));
                  $interval = $current_date->diff($end_date);
                  echo "$interval->days";
                ?>
                 Days Remaining)</p>
              </div>
            </article>
          <?php endforeach; }?>
            
          </div>
        </div>
      </div>

      <div class="col-md-4">
        <div class="x_panel">
          <div class="x_title">
            <h2>Valuable PO <small>This month</small></h2>
            <ul class="nav navbar-right panel_toolbox">
              <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
              </li>
              <li class="dropdown">
                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                <ul class="dropdown-menu" role="menu">
                  <li><a href="#">Settings 1</a>
                  </li>
                  <li><a href="#">Settings 2</a>
                  </li>
                </ul>
              </li>
              <li><a class="close-link"><i class="fa fa-close"></i></a>
              </li>
            </ul>
            <div class="clearfix"></div>
          </div>
          <div class="x_content">
            <?php if($val_po != null){ foreach($val_po as $valueable): ?>
            <article class="media event">
              <a class="pull-left date">
                <p class="month"><?php echo $valueable->bulan; ?></p>
                <p class="day"><?php echo substr($valueable->PENAWARAN_TGL,8,2); ?> </p>
              </a>
              <div class="media-body">
                <!-- Jika nama customer di klik akan mengarah ke page view detail completed PO dengan job number tersebut -->
                <a class="title" href="#"><?php echo $valueable->CUSTOMER_NAMA ?></a>
                <p><strong>Rp <?php echo $valueable->PENAWARAN_NOMINAL ?></strong> (<?php
                  if($valueable->PENAWARAN_KATEGORI == 1){
                    echo"AC";
                  }else if($valueable->PENAWARAN_KATEGORI == 2){
                    echo"DC";
                  }else if($valueable->PENAWARAN_KATEGORI == 3){
                    echo"Transformers";
                  }else if($valueable->PENAWARAN_KATEGORI == 4){
                    echo"Governor";
                  }else if($valueable->PENAWARAN_KATEGORI == 5){
                    echo"Others";
                  }
                ?> Invoice)</p>
                <p>Job Number: <?php echo $valueable->PENAWARAN_KD ?></p>
              </div>
            </article>
          <?php endforeach; } ?>
          </div>
        </div>
      </div>
      
    </div>
  </div>
</div>
