<!-- page content -->
<div class="right_col" role="main">

  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Invoice <small></small></h3>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>List Invoice <small>List invoice yang belum diberi harga final oleh sales manajer </small></h2>
            <ul class="nav navbar-right panel_toolbox">
              <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
              </li>
            </ul>
            <div class="clearfix"></div>
          </div>

          <div class="x_content">

            <!-- <p>List invoice yang belum diberi harga final oleh sales manajer</p> -->

            <!-- <p class="text-muted pull-right">Urutkan</p> -->
            <!-- Tombol Shorting -->
            <!-- <div class="row">
              <div class="btn-group">
                <div class="btn-group">
                  <button data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button"> Shorting <span class="caret"></span> </button>
                  <ul class="dropdown-menu">
                    <li><a href="#">No</a>
                    </li>
                    <li><a href="#">Job Number</a>
                    </li>
                    <li><a href="#">Dropdown link 3</a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>

            <br> -->
            <!-- start project list -->
            <?php if(count($dat_invoice)): $no=1;?>
            <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th style="width: 1%">No</th>
                  <th style="width: 15%">Job Number</th>
                  <th>Category</th>
                  <th>Customer</th>
                  <th>Equipment</th>
                  <th>Brand</th>
                  <th>Status</th>
                  <th style="width: 20%">Action</th>
                </tr>
              </thead>
              <tbody>
                  <?php foreach($dat_invoice as $invoice): ?>
                <tr>
                  <td><?php echo $no++; ?></td>
                  <td>
                    <a><?php echo $invoice->PENAWARAN_KD ?></a>
                    <br />
                    <small>Created <?php echo $invoice->PENAWARAN_TGL ?></small>
                  </td>
                  <td>
                    <a>
                      <?php if($invoice->PENAWARAN_KATEGORI == 1){
                        echo "AC";
                      }else if($invoice->PENAWARAN_KATEGORI == 2){
                        echo "DC";
                      }else if($invoice->PENAWARAN_KATEGORI == 3){
                        echo "Transformers";
                      }else if($invoice->PENAWARAN_KATEGORI == 4){
                        echo "Governor";
                      }else if($invoice->PENAWARAN_KATEGORI == 5){
                        echo "Others";
                      }
                      ?>
                    </a>
                  </td>
                  <td>
                    <a>
                      <?php foreach($dat_customer as $customer):
                        if($invoice->CUSTOMER_KD == $customer->CUSTOMER_KD){
                          echo $customer->CUSTOMER_NAMA;
                        }
                      endforeach; ?>
                    </a>
                  </td>
                  <?php foreach($dat_motor as $motor): ?>
                    <?php if($invoice->MOTOR_KD == $motor->MOTOR_KD){ ?>
                  <td class="project_progress">
                    <a>
                      <?php echo $motor->MOTOR_NAMA; ?>
                    </a>
                  </td>
                  <td>
                    <a>
                      <?php echo $motor->MOTOR_BRAND; ?>
                    </a>
                  </td>
                  <?php } endforeach; ?>
                  <td>
                    <button type="button" class="btn btn-success btn-xs">Completed</button>
                  </td>
                  <td>
                    <a href="<?=base_url('index.php/master-manajer/')?>viewnvc/<?php echo $invoice->PENAWARAN_KD?>" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                    <a href="<?=base_url('index.php/master-manajer/')?>editnvc/<?php echo $invoice->PENAWARAN_KD?>" class="btn btn-warning btn-xs"><i class="fa fa-pencil"></i> Update </a>
                  </td>
                </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
                <?php else: ?>
                <div class="alert alert-info alert-dismissible fade in" role="alert">
                  <strong>Data not found!</strong>
                </div>
              <?php endif; ?>
              
            
            <!-- end project list -->

          </div>
        </div>
      </div>
    </div>
  </div>
</div>
