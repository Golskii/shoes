<!-- page content --> 
<div class="right_col" role="main">
  <?php echo form_open_multipart('manajer/Ctrl_Application/aksi_upload'); ?>
  <div class="">
    <div class="alert alert-info alert-dismissible fade in" role="alert">
      <strong><?php echo $this->session->flashdata("pesan"); ?></strong>
    </div>
    <div class="page-title">
      <div class="title_left">
        <h3>Detail Pending PO <small>Work Instruction </small></h3>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-xs-12">
        <div class="x_panel">
          <div class="x_content">
            <section class="content invoice">
              <div class="row">
                <div class="col-xs-12 invoice-header">
                  <h1 class="green">
                     <i class="fa fa-globe"></i> Pending PO.
                     <br><br>
                      <small class="pull-right green"><b>Deadline: <?=date('F jS, Y', strtotime($dat_order->PO_DATELINE));?></b>

                      </small>
                  </h1>
                </div>
              </div>
              <div class="row invoice-info">
                <br>
                <div class="col-xs-12 col-sm-4 invoice-col">
                  From
                  <address>
                      <strong>
                        <?= $dat_order->USER_NAMA ?>
                      </strong>
                      <br>Alamat: 
                      <br>Phone: 
                      <br>Email: 
                  </address>
                </div>
                <div class="col-xs-12 col-sm-4 invoice-col">
                  To
                  <address>
                      <strong>
                        <?= $dat_order->CUSTOMER_NAMA ?>
                      </strong>
                      <br>Alamat: <?= $dat_order->CUSTOMER_ALAMAT ?>
                      <br>Phone: <?= $dat_order->CUSTOMER_TELP ?>
                      <br>Email: <?= $dat_order->CUSTOMER_EMAIL ?>
                  </address>
                </div>
                <div class="col-xs-12 col-sm-4 invoice-col">
                  <b>Invoice: 
                    <?php switch ($dat_order->PENAWARAN_KATEGORI) {
                      case '1':
                        echo "AC";
                        break;
                      case '2':
                        echo "DC";
                        break;
                      case '3':
                        echo "Transformer";
                        break;
                      case '4':
                        echo "Governor";
                        break;
                      case '5':
                        echo "Other";
                        break;                                                                                         
                      default:
                        # code...
                        break;
                    }?>
                  </b>
                  <br>
                  <b>Job Number: </b> <?= $dat_order->PENAWARAN_KD ?>
                  <br>
                  <b>PO Number: </b> <?= $dat_order->PO_KD ?>
                  <br>
                  <b>Equipment: </b> <?= $dat_order->MOTOR_NAMA ?>
                  <br>
                  <b>Manufacture: </b> <?= $dat_order->MOTOR_BRAND ?>
                </div>
              </div>

              <div class="ln_solid"></div>
              
              <p class="lead">Specification:</p>
              <div class="col-xs-12 col-md-5">
                <table class="table table-striped col-xs-12 col-md-6" >
                  
                    <tr>
                        <th width="40%">HP </th>
                        <th width="5%">: </th>
                        <td><?= $dat_order->MOTOR_HP ?></td>
                    </tr>
                    <tr>
                      <th>KW </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_KW ?></td>
                    </tr>
                    <tr>
                      <th>KVA </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_KVA ?></td>
                    </tr>
                    <tr>
                      <th>Volts (S) </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_VOLTS ?></td>
                    </tr>
                    <tr>
                      <th>Volts </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_VOLTSS ?></td>
                    </tr>
                    <tr>
                      <th>Volts-Ex </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_VOLTS_EX ?></td>
                    </tr>
                    <tr>
                      <th>AMPS </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_AMPS ?></td>
                    </tr>
                    <tr>
                      <th>PH </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_PH ?></td>
                    </tr>
                    <tr>
                      <th>HZ </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_HZ ?></td>
                    </tr>
                  
                </table>
              </div>
              
              <div class="col-xs-12 col-md-offset-1 col-md-5">
                <table class="table table-striped col-xs-12 col-md-6" >
                  <tbody>
                    <tr>
                      <th width="40%">RPM </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_RPM ?></td>
                    </tr>
                    <tr>
                      <th>Frame </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_FRAME ?></td>
                    </tr>
                    <tr>
                      <th>Model </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_MODEL ?></td>
                    </tr>
                    <tr>
                      <th>Type </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_TIPE ?></td>
                    </tr>
                    <tr>
                      <th>Insul CL </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_INSUL_CL ?></td>
                    </tr>
                    <tr>
                      <th>S/Number </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_SNO ?></td>
                    </tr>
                    <tr>
                      <th>Bearing By </th>
                      <th width="5%">: </th>
                      <td>aaaa</td>
                    </tr>
                    <tr>
                      <th>DE Bearing </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_BEARING_DE ?></td>
                    </tr>
                    <tr>
                      <th>NDE Bearing </th>
                      <th width="5%">: </th>
                      <td><?= $dat_order->MOTOR_BEARING_NDE ?></td>
                    </tr>
                  </tbody>
                </table>
              </div>
              
              <div class="row">
                <div class="col-xs-12">
                  <br>
                  <p class="lead">Pricing:</p>

                  <!-- JIKA DIAKSES OLEH SALES MANAGER -->
                  <div class="table-responsive">
                    <table id="" class="table table-striped table-bordered dt-responsive nowrap table-hover" cellspacing="0" width="100%">
                      <thead>
                        <tr>
                          <th width="5%" style="text-align: center; vertical-align: middle;" rowspan="2">
                            Number
                          </th>
                          <th width="30%" rowspan="2" style="text-align: center; vertical-align: middle;">
                            Workscope
                          </th>
                          <th width="20%" style="text-align: center; " colspan="2">
                            Material Cost
                          </th>
                          <th width="20%" style="text-align: center;" colspan="2">
                            Service Cost
                          </th>
                        </tr>
                      <tr>
                        <th style="text-align: center;">Purchaser </th>
                        <th style="text-align: center;">Sales Manager </th>
                        <th style="text-align: center;">Purchaser </th>
                        <th style="text-align: center;">Sales Manager </th>
                      </tr>
                      </thead>
                      <tbody>
                        <?php $i=1; ?> 
                        <tr>
                          <?php foreach ((array)$dat_order->ADDITIONAL as $key =>$additional) { ?>
                          <td style="text-align: center;"><?= $i ?></td>
                          <td>
                            <?php if ($additional['ADDITIONAL_NAMA'] == "Bearing DE") {
                              echo $additional['ADDITIONAL_NAMA']; ?>
                               (<?= $additional['MOTOR_BEARING_DE']?>)
                            <?php }elseif ($additional['ADDITIONAL_NAMA'] == "Bearing NDE") {
                              echo $additional['ADDITIONAL_NAMA']; ?>
                               (<?= $additional['MOTOR_BEARING_NDE']?>)
                            <?php }else{ 
                              echo $additional['ADDITIONAL_NAMA'];
                            } ?>
                          </td>
                          <td style="text-align: right;"> Rp. <?= $additional['HARGA_MATERIAL_PR'] ?></td>
                          <td style="text-align: right;"> Rp. <?= $additional['HARGA_MATERIAL_SM'] ?></td>
                          <td style="text-align: right;"> Rp. <?= $additional['HARGA_JASA_PR'] ?></td>
                          <td style="text-align: right;"> Rp. <?= $additional['HARGA_JASA_SM'] ?></td>
                        </tr>
                        <?php $i++;}?>
                        <tr>
                          <?php foreach ((array)$dat_order->CUSTOM as $key =>$custom) { ?>
                          <td style="text-align: center;"><?= $i ?></td>
                          <td><?= $custom['CUSTOM_NAMA'] ?></td>
                          <td style="text-align: right;"> Rp. <?= $custom['HARGA_MATERIAL_PR'] ?></td>
                          <td style="text-align: right;"> Rp. <?= $custom['HARGA_MATERIAL_SM'] ?></td>
                          <td style="text-align: right;"> Rp. <?= $custom['HARGA_JASA_PR'] ?></td>
                          <td style="text-align: right;"> Rp. <?= $custom['HARGA_JASA_SM'] ?></td>
                        </tr>
                        <?php $i++;}?>

                      </tbody>
                    </table>
                  </div>
                  
                </div>
              </div>

              <div class="row">
                <div class="col-xs-12 col-md-5">
                  <br>

                  <p class="lead">Workscope:</p>
                  <table class="table table-striped">
                    <tbody>
                      <?php $i=1; foreach ((array) $dat_order->WORK as $key => $work) { if ($work == 1) { ?>
                      <tr>
                        <td width="5%"><b><?= $i ?></b></td>
                        <td><?php echo str_replace("_", " ",$key)."<br>"; ?></td>
                      </tr>
                      <?php $i++; }}?>
                    </tbody>
                  </table>
                </div>
                <br>
                <div class="col-xs-12 col-md-6 col-md-offset-1">
                  <p class="lead">Detail Payment</p>
                  <div class="table-responsive">
                    <table class="table table-striped table-hovered">
                      <tbody>
                        <tr>
                          <th width="50%">Material Subtotal</th>
                          <th width="5%">:</th>
                          <td> 
                            <div class="col-xs-12 col-md-6 form-group">
                            <input readonly type="text" id="material_sm" class="form-control" name=""  required="required" value="<?php echo $dat_material_total; ?>" />
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th width="50%">Service Subtotal</th>
                          <th width="5%">:</th>
                          <td> 
                            <div class="col-xs-12 col-md-6 form-group">
                            <input readonly type="text" id="jasa_sm" class="form-control" name=""  required="required" value="<?php echo $dat_service_total; ?>" />
                            </div>
                          </td>
                        </tr>
                        <tr>
                          <th>Total</th>
                          <th width="5%">:</th>
                          <td> 
                            <div class="col-xs-12 col-md-6 form-group">
                            <input readonly type="text" id="total_sm" class="form-control" name="total_sm"  required="required" value="<?= $dat_order->PENAWARAN_NOMINAL ?>" />
                            </div>
                           </td>
                        </tr>
                      </tbody>
                    </table>
                  </div>
                  
                </div>
              </div>
              <div class="clearfix"></div>
              <div class="ln_solid"></div>

              <!-- MUNCUL JIKA DIAKSES OLEH SALES -->
              <div class="row no-print">
                <div class="col-xs-12">
                  <a href="" class="btn btn-warning pull-right">  Generate PDF </a>
                  <!-- <button class="btn btn-success pull-right" >Add to Purchase Order </button>
                  <button class="btn btn-primary pull-right" >Send to Customer </button> -->
                </div>
              </div>

              <!-- MUNCUL JIKA DIAKSES OLEH SALES MANAGER -->
              <!-- <div class="row no-print">
                <div class="col-xs-12">
                  <button class="btn btn-success pull-right"><i class="fa fa-print"></i>&nbsp; Generate PDF</button>
                </div>
              </div> -->
            </section>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>



<!-- /page content