<!-- page content -->
  <div class="right_col" role="main">

    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Purchase Order <small></small></h3>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>Processed Purchase Order <small>Daftar purchase order yang sudah ada kiriman barang dari customer dan sedang dalam pengerjaan </small></h2>
              <ul class="nav navbar-right panel_toolbox">
                <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
                </li>
              </ul>
              <div class="clearfix"></div>
            </div>

            <div class="x_content">

              <!-- <p>Daftar purchase order yang sudah ada kiriman barang dari customer dan sedang dalam pengerjaan</p> -->

              <!-- <div class="row">
                <div class="btn-group">
                  <div class="btn-group">
                    <button data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button"> Shorting <span class="caret"></span> </button>
                    <ul class="dropdown-menu">
                      <li><a href="#">No</a>
                      </li>
                      <li><a href="#">Job Number</a>
                      </li>
                      <li><a href="#">Dropdown link 3</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <br> -->

              <!-- start project list -->
              <?php if (is_null($dat_order)) { ?>
                <div class="alert alert-info alert-dismissible fade in" role="alert">
                  <strong>data not found!</strong>
                </div>
              <?php }else{ ?>
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th style="width: 1%; text-align: center;">No</th>
                    <th style="width: 12%; text-align: center;">PO Number</th>
                    <th style="width: 12%; text-align: center;">Job Number</th>
                    <th style="text-align: center;">Customer</th>
                    <th style="text-align: center;">Equipment</th>
                    <th style="text-align: center;">Brand</th>
                    <th style="text-align: center;">Nominal</th>
                    <th style="text-align: center;">Deadline</th>
                    <th style="width: 10%; text-align: center;">Action</th>

                  </tr>
                </thead>
                <tbody>
                  <?php $no=0; foreach($dat_order as $order) { $no++; ?>
                    <tr>
                      <td><?= $no ?></td>
                      <td><?= $order->PO_KD ?></td>
                      <td>
                        <a><?= $order->PENAWARAN_KD ?></a>
                        <br>
                        <small>Created <?= $order->PENAWARAN_TGL ?></small>
                      </td>
                      <td><?= $order->CUSTOMER_NAMA ?></td>
                      <td><?= $order->MOTOR_NAMA ?></td>
                      <td><?= $order->MOTOR_BRAND ?></td>
                      <td><?= $order->PENAWARAN_NOMINAL ?></td>
                      <td  style="text-align: center;"><?php if($order->PO_DATELINE >= date("Y-m-d")){ ?> 
                        <button class="btn btn-danger btn-xs btn-round">
                          <?= $order->PO_DATELINE; ?>
                        </button>
                        <?php }else{ ?>
                          <button class="btn btn-warning btn-xs btn-round">
                              <?= $order->PO_DATELINE; }?>
                          </button>
                      </td>
                      <td  style="text-align: center;">
                        <a href="<?=base_url('index.php/master-manajer/')?>viewprocesspo/<?php echo $order->PENAWARAN_KD?>" class="btn btn-primary btn-sm"><i class="fa fa-folder-open"></i> </a>
                        <a href="#" class="btn btn-success btn-sm"><i class="fa fa-check"></i> </a>
                      </td>
                    <tr>
                  <?php } ?>
                   
                </tbody>
              </table>
              <!-- end project list -->
              <?php } ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>