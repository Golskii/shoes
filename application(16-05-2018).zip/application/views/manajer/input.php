<div class="col-md-7 col-sm-7 col-xs-12" >
	<input type="checkbox" name="item_index[]" />
	<input id="ADDITIONAL_NAMA" name="ADDITIONAL_NAMA[]" type="text" />
</div>	