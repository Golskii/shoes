<?php
require ('application/libraries/fpdf.php');

class PDF extends FPDF
{
	function Footer()
	{
		// Page footer
		//Pages numbering
		$this->SetY(-15);
		$this->SetFont('Arial','I',8);
		$this->SetTextColor(128);
		$this->Cell(0,10,'Page '.$this->PageNo(),0,0,'C');
		$page = $this->PageNo();
	}
}

$pdf = new PDF();
$pdf->AddPage();
if($dat_penawaran->PENAWARAN_KATEGORI == 1){
    $kategori = "AC";
}else if($dat_penawaran->PENAWARAN_KATEGORI == 2){
    $kategori = "DC";
}else if($dat_penawaran->PENAWARAN_KATEGORI == 3){
	$kategori = "Transformers";
}else if($dat_penawaran->PENAWARAN_KATEGORI == 4){
	$kategori = "Governor";
}else if($dat_penawaran->PENAWARAN_KATEGORI == 5){
	$kategori = "Others";
}
//Make a dumy empty cell as a vertical spacer
// Page header
//Image(file name, x position, y position, width [optional], height [optional])
$pdf->Image('assets/images/header_pdf.png',0,0,210);
//Cell(width, height, text, border, endline, [align])
$pdf->Cell(189, 40, '', 0, 1, 'C');
//Info box, Customer and Sales, kotal atas
// Move to 8 cm to the right, baris 1
$pdf->Cell(20);
$pdf->Cell(80,5,'','TLR',0,'L');
$pdf->Cell(80,5,'','TLR',1,'L');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20);
$pdf->Cell(80,5,'To :','LR',0,'L');
$pdf->Cell(80,5,'From :','LR',1,'L');
// Move to 8 cm to the right, baris 2
$pdf->Cell(20);
$pdf->SetFont('Arial','B',18);
foreach($dat_customer as $customer):
$pdf->Cell(80,5,$customer->CUSTOMER_NAMA,'LR',0,'L');
endforeach;
$pdf->SetFont('Arial','B',10);
foreach($dat_sales as $sales):
$pdf->Cell(80,5,$sales->USER_NAMA,'LR',1,'L');
endforeach;
// Move to 8 cm to the right, baris 3
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20);
$pdf->Cell(80,5,'Nama Customer','LR',0,'C');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(80,5,'Dept Krywn','LR',1,'L');
//Horizontal Spacer
$pdf->Cell(20);
$pdf->Cell(80, 10, '', 'BLR', 0, 'C');
$pdf->Cell(80, 10, '', 'BLR', 1, 'C');
//Kotak bawah
//Baris 1
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20);
$pdf->Cell(80,8,'[  ]  Urgent','LR',0,'L');
$pdf->Cell(13,8,'Date','L',0,'L');$pdf->Cell(67,8,' : '.date('d M Y'),'TR',1,'L');
//Baris 2
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20);
$pdf->Cell(80,8,'[  ]  For review','LR',0,'L');
$pdf->Cell(13,8,'No','L',0,'L');$pdf->Cell(67,8,' : '.$dat_penawaran->PENAWARAN_KD,'R',1,'L');
//Baris 3
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20);
$pdf->Cell(80,8,'[  ]  Please comment','LR',0,'L');
$pdf->Cell(13,8,'Subject :','L',0,'L');$pdf->Cell(67,8,' : '.$kategori.' Motor '.$dat_motor->MOTOR_KW.'KW','R',1,'L');
//Baris 4
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20);
$pdf->Cell(80,8,'[  ]  Please reply','BLR',0,'L');
$pdf->Cell(13,8,'Total','BL',0,'L');$pdf->Cell(67,8,' : '.$page,'BR',1,'L');

//Spacer
$pdf->Cell(189, 8, '', 0, 1, 'C');
//Kalimat
$pdf->SetFont('Arial','',10);
$pdf->Cell(20);
$pdf->Cell(80,8,'Dengan Hormat,',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(12,8,'',0,0,'L');
$pdf->Cell(80,8,'Dengan ini kami mengajukan penawaran untuk pekerjaan perbaikan 1(satu) unit '.$kategori.' Motor',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'dengan spesifikasi sebagai berikut :',0,1,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
$pdf->Cell(20,8,'Brand',0,0,'L'); $pdf->Cell(50,8,':  '.$dat_motor->MOTOR_BRAND,0,1,'L');
$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
$pdf->Cell(20,8,'Daya',0,0,'L'); $pdf->Cell(50,8,':  '.$dat_motor->MOTOR_KW.' KW',0,1,'L');
$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
$pdf->Cell(20,8,'Volt',0,0,'L'); $pdf->Cell(50,8,':  '.$dat_motor->MOTOR_VOLTSS,0,1,'L');
$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
$pdf->Cell(20,8,'RPM',0,0,'L'); $pdf->Cell(50,8,':  '.$dat_motor->MOTOR_RPM,0,1,'L');
$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
$pdf->Cell(20,8,'S/N',0,0,'L'); $pdf->Cell(50,8,':  '.$dat_motor->MOTOR_SNO,0,1,'L');
$pdf->Cell(20);
$pdf->Cell(20,8,'Sesuai dengan hasil pemeriksaan, kami tawarkan pekerjaan perbaikan dengan perincian sebagai berikut :',0,1,'L');
$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
$pdf->Cell(20,8,'> '.$dat_perbaikan->PERBAIKAN_NAMA,0,1,'L');
$pdf->Cell(20); $pdf->Cell(28,8,'',0,0,'L');
$pdf->Cell(20,8,'- Bahan : ',0,0,'L');$pdf->Cell(5,8,'',0,0,'L');$pdf->Cell(20,8,'...................',0,0,'C');
$pdf->Cell(5,8,'',0,0,'C');$pdf->Cell(5,8,'Rp. ',0,0,'C');$pdf->Cell(20,8,$dat_material_total.',00',0,1,'L');
$pdf->Cell(20); $pdf->Cell(28,8,'',0,0,'L');
$pdf->Cell(20,8,'- Jasa : ',0,0,'L');$pdf->Cell(5,8,'',0,0,'L');$pdf->Cell(20,8,'...................',0,0,'C');
$pdf->Cell(5,8,'',0,0,'C');$pdf->Cell(5,8,'Rp. ',0,0,'C');$pdf->Cell(20,8,$dat_service_total.',00',0,1,'L');
$pdf->Cell(20); $pdf->Cell(28,8,'',0,0,'L');
$pdf->Cell(25,8,'',0,0,'L');$pdf->Cell(55,8,'+','B',1,'R');
$pdf->SetFont('Arial','B',10);
$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
$pdf->Cell(20,8,'TOTAL ',0,0,'L');$pdf->Cell(19,8,'',0,0,'L');$pdf->Cell(20,8,'...................',0,0,'C');
$pdf->Cell(5,8,'',0,0,'C');$pdf->Cell(5,8,'Rp. ',0,0,'C');$pdf->Cell(20,8,$dat_penawaran->PENAWARAN_NOMINAL.',00',0,1,'L');
$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
$pdf->Cell(20,8,'(Terbilang : '.$dat_terbilang.' )',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(20,8,'Detail scope pekerjaan sebagai berikut :',0,1,'L');
$L=0;
foreach($dat_work as $workscope):
    foreach($workscope as $Eworkscope):
        if(isset($Eworkscope) && $L != 0){
        	$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
        	$pdf->SetFont('Arial','B',10);
			$pdf->Cell(3,8,'> ',0,0,'L');
			$pdf->SetFont('Arial','',10);
			$pdf->Cell(20,8,' '.str_replace("_", " ",$dat_view_list_workscope[$L]),0,1,'L');
        }
    	$L++;
    endforeach;
endforeach;
if(count($dat_additional) || count($dat_custom)){
	if(count($dat_additional)){
		$i = 1;
		foreach($dat_additional as $additional):
			if($additional->ADDITIONAL_NAMA != "Bearing DE" && $additional->ADDITIONAL_NAMA != "Bearing NDE"){
				$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
    	    	$pdf->SetFont('Arial','B',10);
				$pdf->Cell(3,8,'> ',0,0,'L');
				$pdf->SetFont('Arial','',10);
				$pdf->Cell(20,8,' '.$additional->ADDITIONAL_NAMA,0,1,'L');
				$i++ ;
			}
		endforeach; 
	}
	if(count($dat_custom)){
        foreach($dat_custom as $custom):
        	$pdf->Cell(20); $pdf->Cell(14,8,'',0,0,'L');
        	$pdf->SetFont('Arial','B',10);
			$pdf->Cell(3,8,'> ',0,0,'L');
			$pdf->SetFont('Arial','',10);
			$pdf->Cell(20,8,' '.$custom->CUSTOM_NAMA,0,1,'L');
        	$i++; 
        endforeach; 
    }
}

$pdf->Cell(20);
$pdf->Cell(80,8,'Estimasi lama pengerjaan adalah  selama 6(enam) hari kerja  terhitung per  tanggal pengambilan motor ',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'dan Purchase order kami terima.',0,1,'L');
$pdf->Cell(80,5,'',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'Harga diatas belum termasuk PPN 10.',0,1,'L');
$pdf->Cell(80,5,'',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'Masa garansi untuk pekerjaan diatas adalah selama 3(tiga) bulan, terhitung setelah serah terima motor. ',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'Garansi  tidak  berlaku  jika  kerusakan  disebabkan  oleh  kesalahan pengoperasian, kegagalan  sistem ',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'pengaman, kelalaian pemeliharaan, dan over-load.',0,1,'L');
$pdf->Cell(80,5,'',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'Pembayaran harap diselesaikan maksimal 30 hari setelah pekerjaan selesai.',0,1,'L');
$pdf->Cell(80,5,'',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'Masalah-masalah diluar scope pekerjaan diatas akan dilakukan negosiasi lebih lanjut.',0,1,'L');
$pdf->Cell(80,5,'',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(80,8,'Demikian penawaran kami, atas perhatian dan kerjasamanya, kami ucapkan terima kasih.',0,1,'L');
$pdf->Cell(80,5,'',0,1,'L');
$pdf->Cell(20);
$pdf->Cell(100,8,'',0,0,'R');
$pdf->Cell(20,8,'Hormat kami',0,1,'L');
$pdf->Cell(80,20,'',0,1,'L');
$pdf->Cell(20);
$pdf->SetFont('Arial','B',10);
$pdf->Cell(100,8,'',0,0,'R');
$pdf->Cell(20,8,'Irfansyah',0,1,'L');
$pdf->SetFont('Arial','',10);
$pdf->Cell(20);
$pdf->Cell(100,8,'',0,0,'R');
$pdf->Cell(20,8,'Sales Admin',0,1,'L');



$pdf->Output();
?>