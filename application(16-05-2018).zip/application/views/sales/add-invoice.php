<!-- page content -->
  <div class="right_col" role="main">

	<form id="demo-form" data-parsley-validate action>
	  <div class="">
	    <div class="page-title">
	      <div class="title_left">
	        <h3>Add Invoice <small>Work Instruction </small></h3>
	      </div>
	  	</div>
	  	<div class="clearfix"></div>
	    <div class="row">
	      <div class="col-md-12 col-sm-12 col-xs-12">
	        <div class="x_panel">
	          <div class="x_title">
	            <h2>General Information <small> </small></h2>
	            <ul class="nav navbar-right panel_toolbox">
		          <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
		          </li>
		        </ul>
	            <div class="clearfix"></div>
	          </div>
	          <div class="x_content">
	            <br />
	            <!-- start form for validation -->
	              <fieldset>
	                  <div class="control-group">
	                    <div class="controls">
	                      <div class="col-md-5 xdisplay_inputx form-group has-feedback">
	                      	<label for="date-invoice">Date Received * :</label>
	                        <input type="text" class="form-control has-feedback-left" id="single_cal3" placeholder="First Name" aria-describedby="inputSuccess2Status3">
	                        <span class="fa fa-calendar-o form-control-feedback left" aria-hidden="true"></span>
	                        <span id="inputSuccess2Status3" class="sr-only">(success)</span>
	                      </div>
	                    </div>
	                  </div>
	                </fieldset>
                  <div class="col-sm-5 col-md-5 col-xs-12">
                  	
                    <label for="sales">Sales :</label>
	                <input type="text" id="fullname" class="form-control" name="sales"  readonly="readonly"/>

	                <label for="customer">Customer * :</label>
	                <input type="text" id="autocomplete-custom-append"" class="form-control" name="customer" required="required" />

	                <label for="equipment">Equipment * :</label>
	                <input type="text" id="equipment" class="form-control" name="equipment" required="required" />


                  </div>
                  <div class="col-sm-offset-1 col-sm-5 col-md-5 col-xs-12">
                  	
	                <label for="job-number">Job Number :</label>
	                <input type="text" id="job-number" class="form-control" name="job-number"  readonly="readonly"/>

	                <label for="category">Categeory</label>
                      <select class="select2_single form-control" tabindex="-1">
                        <option></option>
                        <option value="AK">AC</option>
                        <option value="AK">DC</option>
                        <option value="AK">Governor</option>
                    </select>

	                <label for="brand">Brand/Manufacture * :</label>
	                <input type="text" id="brand" class="form-control" name="brand"  required="required" />
	                
                  </div>
                <!-- end form for validations -->
	      	  </div>
	  		</div>
	  		<div class="x_panel">
	          <div class="x_title">
	            <h2>Specification Detail <small> </small></h2>
	            <ul class="nav navbar-right panel_toolbox">
		          <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
		          </li>
		        </ul>
	            <div class="clearfix"></div>
	          </div>
	          <div class="x_content">
	            <br />

                  <div class="col-sm-2 col-md-2 col-xs-2">
                  	
	                <label for="hp">HP :</label>
	                <input type="text" id="hp" class="form-control" name="hp" />

	                <label for="kw">KW * :</label>
	                <input type="text" class="form-control" data-inputmask="'mask': '9,999'" id="kw" required="required" />
                      <span aria-hidden="true"></span>

	                <label for="kva">KVA :</label>
	                <input type="text" id="kva" class="form-control" name="kva" />

	                <label for="frame">Frame :</label>
	                <input type="text" id="frame" class="form-control" name="frame" />

	                <label for="insul">Insul. CL :</label>
	                <input type="text" id="insul" class="form-control" name="insul" />

                  </div>

                  <div class="col-sm-offset-1 col-sm-2 col-md-2 col-xs-2">
                  	<label for="volts1">Volts * :</label>
                      <input type="text" class="form-control" data-inputmask="'mask': '999/999'" id="volts1" required="required" />
                      <span aria-hidden="true"></span>

	                <label for="volts2">VOLts* :</label>
	                <input type="text" id="volts2" class="form-control" name="volts2" />

	                <label for="volts3">Volts-Ex :</label>
	                <input type="text" id="volts3" class="form-control" name="volts3" />

	                <label for="model">Model :</label>
	                <input type="text" id="model" class="form-control" name="model" />

	                <label for="bearing-order">Bearing By * :</label>
	                  <div id="bearing-order" class="btn-group" data-toggle="buttons">
	                    <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
	                      <input type="radio" name="bearing-order" value="yes"> &nbsp; SWTS &nbsp;
	                    </label>
	                    <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
	                      <input type="radio" name="bearing-order" value="no">  Client 
	                    </label>
	                  </div>

                  </div>

                  <div class="col-sm-offset-1 col-sm-2 col-md-2 col-xs-2">
                  	
	                <label for="amps1">AMPS * :</label>
	                <input type="text" class="form-control" data-inputmask="'mask': '9,99/9,99'" id="amps1" required="required" />
                      <span aria-hidden="true"></span>

	                <label for="amps2">AMPS :</label>
	                <input type="text" id="amps2" class="form-control" name="amps2" />

	                <label for="amps3">AMPS :</label>
	                <input type="text" id="amps3" class="form-control" name="amps3" />

	                <label for="type">Type * :</label>
	                <input type="text" id="type" class="form-control" name="type" />

	                <label for="de-bearing">DE Bearing :</label>
	                <input type="text" id="de-bearing" class="form-control" name="de-bearing" />
                  </div>

                  <div class="col-sm-offset-1 col-sm-2 col-md-2 col-xs-12">
                  	
	                <label for="ph">PH :</label>
	                <input type="text" id="ph" class="form-control" name="ph" />

	                <label for="hz">HZ * :</label>
	                <div id="bearing-order" class="btn-group" data-toggle="buttons">
	                    <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
	                      <input type="radio" name="bearing-order" value="yes"> &nbsp; 50 DC&nbsp;
	                    </label>
	                    <label class="btn btn-default" data-toggle-class="btn-primary" data-toggle-passive-class="btn-default">
	                      <input type="radio" name="bearing-order" value="no">  60 DC 
	                    </label>
	                </div>

                    <label for="rpm">RPM * :</label>
	                <input type="text" id="rpm" class="form-control" name="rpm" required="required"/>

	                <label for="s-no">S/Number * :</label>
	                <input type="text" id="s-no" class="form-control" name="s-no" />

	                <label for="nde-bearing">NDE Bearing :</label>
	                <input type="text" id="nde-bearing" class="form-control" name="nde-bearing" />
                  </div>

                <!-- end form for validations -->
	      	  </div>
	  		</div>
	  	  </div>
	  	<!-- </div> -->

	  	  <div class="col-md-6 col-xs-12">
	  		<div class="x_panel">
	          <div class="x_title">
	            <h2>Workscope Conducted <small> </small></h2>
	            <ul class="nav navbar-right panel_toolbox">
		          <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
		          </li>
		        </ul>
	            <div class="clearfix"></div>
	          </div>
	          <div class="x_content">
	            <br />
	            <div class="col-sm-6 col-md-6 col-xs-12">
	              <div class="checkbox">
	            	<ul class="to_do">
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Site Work" class="flat"> &nbsp; Site Work
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Initial Testing" class="flat"> &nbsp; Initial Testing
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Disassembly" class="flat"> &nbsp; Disassembly
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Reassemble" class="flat"> &nbsp; Reassemble
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Steam / Chemical" class="flat"> &nbsp; Steam / Chemical Clean
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Bake Windings" class="flat"> &nbsp; Bake Windings
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Rewind" class="flat"> &nbsp; Rewind
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Varnish Treatment" class="flat"> &nbsp; Varnish Treatment
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" value="Bake and Cure" class="flat"> &nbsp; Bake and Cure
	            			</p>
	            		</li>
						<li>
	            			<p>
	                      	<input type="checkbox" value="Final Test - No Load" class="flat"> &nbsp; Final Test - No Load
	            			</p>
	            		</li>
	            	</ul>
	              </div>
	            </div>


	            <div class="col-md-6 col-sm-6 col-xs-12">
	              <!-- <div class="checkbox"> -->
	            	<ul class="to_do">
	            		<div class="checkbox">
	            		<li>
	            			<p>
	                      	<input type="checkbox" class="flat"> &nbsp; Dynamic Balance
	            			</p>
	            		</li>
						<li>
	            			<p>
	                      	<input type="checkbox" class="flat"> &nbsp; Skim and Under
	            			</p>
	            		</li>
						<li>
	            			<p>
	                      	<input type="checkbox" class="flat"> &nbsp; Renew Carbon Brushes
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" class="flat"> &nbsp; Rebush Housing
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" class="flat"> &nbsp; Repair Journal
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" class="flat"> &nbsp; Rebbit Sleeve
	            			</p>
	            		</li>
	            		<li>
	            			<p>
	                      	<input type="checkbox" class="flat"> &nbsp; Labyrinth Seals
	            			</p>
	            		</li>
	            		</div>
	            	</ul>
	        	</div>


	          </div>
          	</div>
    	  </div>

	    <div class="col-md-6 col-xs-12">
	  		<div class="x_panel">
	          <div class="x_title">
	            <h2>Additional Workscope <small> </small></h2>
	            <ul class="nav navbar-right panel_toolbox">
		          <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
		          </li>
		        </ul>
	            <div class="clearfix"></div>
	          </div>
	          <div class="x_content">
	          	<div class="form-group col-md-12 col-xs-12">
		          	<label for="additional1" class="control-label col-md-5 col-sm-5 col-xs-12" ">Additional Workscope 1 :</label>
		          	<div class="col-md-7 col-sm-7 col-xs-12">
		          		<textarea class="resizable_textarea form-control" placeholder="" name="additional1"></textarea>
		          	</div>
		        </div>

		          <div class="form-group col-md-12 col-xs-12">
		          	<label for="additional2" class="control-label col-md-5 col-sm-5 col-xs-12" ">Additional Workscope 2 :</label>
		          	<div class="col-md-7 col-sm-7 col-xs-12">
		          		<textarea class="resizable_textarea form-control" placeholder="" name="additional2"></textarea>
		          	</div>
		          </div>

	          	<div class="col-sm-offset-5 col-md-6 col-xs-12">
	          		<br>
		          	<button class="btn btn-primary" type="button">Add</button>
	                <button class="btn btn-success" type="button">Cancel</button>
	            </div>

	          </div>
	      </div>
	  </div>
	  </div>
      <div class="x_panel">
      	<div class="x_content">
          <div class="form-group">
          	<div class="col-sm-offset-4 col-md-6 col-xs-12">
              <button class="btn btn-primary" type="button">Cancel</button>
              <button class="btn btn-primary" type="reset">Reset</button>
              <button id="submit-all" type="submit" class="btn btn-success">Submit</button>
          	</div>
          </div>
      	</div>
      </div>
	</form>
  </div>

<!-- /page content -->
