<?php
  $no   = 1;
  $data = 0;
?>

<!-- page content -->
  <div class="right_col" role="main">

    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Invoice <small></small></h3>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>List Invoice <small>List invoice yang belum diberi harga final oleh sales manajer </small></h2>
              <ul class="nav navbar-right panel_toolbox">
                <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
                </li>
              </ul>
              <div class="clearfix"></div>
            </div>

            <div class="x_content">

              <!-- <p>List invoice yang belum diberi harga final oleh sales manajer</p> -->

              <!-- <p class="text-muted pull-right">Urutkan</p> -->
              <div class="row">
                <div class="btn-group">
                  <div class="btn-group">
                    <button data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button"> Shorting <span class="caret"></span> </button>
                    <ul class="dropdown-menu">
                      <li><a href="#">No</a>
                      </li>
                      <li><a href="#">Job Number</a>
                      </li>
                      <li><a href="#">Dropdown link 3</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <br>
              <!-- start project list -->
              <table id="datatable-responsive" class="table table-striped table-bordered dt-responsive nowrap" cellspacing="0" width="100%">
                <thead>
                  <tr>
                    <th style="width: 1%">No</th>
                    <th style="width: 15%">Job Number</th>
                    <th>Category</th>
                    <th>Customer</th>
                    <th>Equipment</th>
                    <th>Brand</th>
                    <th>Status</th>
                    <th style="width: 20%">Action</th>

                  </tr>
                </thead>
                <tbody>
                  <?php if(count($this->page['invoice'])): ?>
                    <?php foreach ($this->page['invoice'] as $invoice):?>
                      <?php if($invoice->PENAWARAN_NOMINAL == 0):?>
                        <?php $data++; ?>
                      <tr>
                        <td> <?php echo $no++;?> </td>
                        <td>
                          <a><?php echo $invoice->PENAWARAN_KD;?></a>
                          <br />
                          <small>Created <?php echo $invoice->PENAWARAN_TGL;?></small>
                        </td>
                        <td>
                          <a><?php 
                            if($invoice->PENAWARAN_KATEGORI == 1)
                            {
                              echo "AC";
                            }else if($invoice->PENAWARAN_KATEGORI == 2)
                            {
                              echo "DC";
                            }
                            else if($invoice->PENAWARAN_KATEGORI == 3)
                            {
                              echo "Governor";
                            }
                          ?></a>
                        </td>
                        <td>
                          <?php $CUSTOMER_KD =  $invoice->CUSTOMER_KD; ?>
                          <a><?php  
                          foreach ($this->page['customer'] as $customer):
                            if($customer->CUSTOMER_KD == $invoice->CUSTOMER_KD)
                            {
                              echo $customer->CUSTOMER_NAMA;
                            }
                          endforeach;
                          ?></a>
                        </td>
                        <td class="project_progress">
                          <a>Motor</a>
                        </td>
                        <td>
                          <a>Panasonic</a>
                        </td>
                        <td>
                          <button type="button" class="btn btn-warning btn-xs">Uncomplete</button>
                        </td>
                        <td>
                          <a href="<?=base_url()?>viewnvc/<?php{$invoice->PENAWARAN_KD}?>" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                          <a href="<?=base_url()?>editnvc/<?php{$invoice->PENAWARAN_KD}?>" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                          <a href="#" class="btn btn-dark btn-xs"><i class="fa fa-check"></i> Fix </a>
                        </td>
                      </tr>
                    <?php endif; ?>
                    <?php endforeach; ?>
                    <?php if($data == 0):?>
                      <tr>
                        <td>No Record Found!</td>
                      </tr>
                    <?php endif; ?>
                  <?php else: ?>
                    <tr>
                      <td>No Record Found!</td>
                    </tr>
                  <?php endif; ?>  
                </tbody>
              </table>
              <!-- end project list -->

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>