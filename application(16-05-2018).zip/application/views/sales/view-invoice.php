<!-- page content -->
<div class="right_col" role="main">

  <div class="">
    <div class="page-title">
      <div class="title_left">
        <h3>Invoice <small></small></h3>
      </div>
    </div>
    <div class="clearfix"></div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12">
        <div class="x_panel">
          <div class="x_title">
            <h2>Detail Invoice <small>Detail invoice yang belum diberi harga final oleh sales manajer </small></h2>
            <ul class="nav navbar-right panel_toolbox">
              <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
              </li>
            </ul>
            <div class="clearfix"></div>
          </div>

          <div class="x_content">
          	<div class="row">

          			<div class="col-md-3 col-sm-3 col-xs-4"><p>Date Received</p></div>
		          	<div class="col-md-9 col-sm-9 col-xs-8"><p>: 12 January 2017</p></div>

		          	<div class="col-md-3 col-sm-3 col-xs-4"><p>Job Number</p></div>
		          	<div class="col-md-9 col-sm-9 col-xs-8"><p>: 123423422</p></div>

		          	<div class="col-md-3 col-sm-3 col-xs-4"><p>Sales</p></div>
		          	<div class="col-md-9 col-sm-9 col-xs-8"><p>: Ardiansyah Bayu</p></div>

		          	<div class="col-md-3 col-sm-3 col-xs-4"><p>Customer</p></div>
		          	<div class="col-md-9 col-sm-9 col-xs-8"><p>: PT. Campina</p></div>

		          </div>
		      </div>
		      
			  </div>
			</div>
		</div>
	</div>
</div>