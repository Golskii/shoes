<!-- page content -->
  <div class="right_col" role="main">

    <div class="">
      <div class="page-title">
        <div class="title_left">
          <h3>Purchase Order <small></small></h3>
        </div>
      </div>
      <div class="clearfix"></div>
      <div class="row">
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="x_panel">
            <div class="x_title">
              <h2>Processed Purchase Order <small>Daftar purchase order yang sudah ada kiriman barang dari customer dan sedang dalam pengerjaan </small></h2>
              <ul class="nav navbar-right panel_toolbox">
                <li class="pull-right"><a class="collapse-link"><i class="fa fa-chevron-down"></i></a>
                </li>
              </ul>
              <div class="clearfix"></div>
            </div>

            <div class="x_content">

              <!-- <p>Daftar purchase order yang sudah ada kiriman barang dari customer dan sedang dalam pengerjaan</p> -->

              <div class="row">
                <div class="btn-group">
                  <div class="btn-group">
                    <button data-toggle="dropdown" class="btn btn-default dropdown-toggle" type="button"> Shorting <span class="caret"></span> </button>
                    <ul class="dropdown-menu">
                      <li><a href="#">No</a>
                      </li>
                      <li><a href="#">Job Number</a>
                      </li>
                      <li><a href="#">Dropdown link 3</a>
                      </li>
                    </ul>
                  </div>
                </div>
              </div>

              <br>

              <!-- start project list -->
              <table class="table table-striped projects">
                <thead>
                  <tr>
                    <th style="width: 1%">No</th>
                    <th style="width: 12%">PO Number</th>
                    <th style="width: 12%">Job Number</th>
                    <th>Customer</th>
                    <th>Equipment</th>
                    <th>Brand</th>
                    <th>Nominal</th>
                    <th>Deadline</th>
                    <th style="width: 15%">Action</th>

                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>
                      <a>2010450666</a>
                      <br />
                      <small>Created 01-01-2015</small>
                    </td>
                    <td>
                      <a>1708010933</a>
                    </td>
                    <td>
                      <a>PT. Campina</a>
                    </td>
                    <td class="project_progress">
                      <a>Motor</a>
                    </td>
                    <td>
                      <a>Siemens</a>
                    </td>
                    <td>
                      <a>Rp 6.000.000</a>
                    </td>
                    <td>
                      <!-- <a>02-01-2015</a> -->
                      <a href="#" class="btn btn-round btn-warning btn-xs">02-01-2015 </a>
                    </td>
                    <td>
                      <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                      <a href="#" class="btn btn-info btn-xs"><i class="fa fa-folder"></i> Edit </a>
                    </td>
                  </tr>

                  <tr>
                    <td>2</td>
                    <td>
                      <a>2010450666</a>
                      <br />
                      <small>Created 01-01-2015</small>
                    </td>
                    <td>
                      <a>1708010988</a>
                    </td>
                    <td>
                      <a>PT. Djarum Super</a>
                    </td>
                    <td class="project_progress">
                      <a>Motor</a>
                    </td>
                    <td>
                      <a>Panasonic</a>
                    </td>
                    <td>
                      <a>Rp 3.500.000</a>
                    </td>
                    <td>
                      <!-- <a>02-01-2015</a> -->
                      <a href="#" class="btn btn-round btn-danger btn-xs">02-01-2015 </a>
                    </td>
                    <td>
                      <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                      <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                    </td>
                  </tr>

                  <tr>
                    <td>3</td>
                    <td>
                      <a>2010450777</a>
                      <br />
                      <small>Created 01-01-2015</small>
                    </td>
                    <td>
                      <a>1708010999</a>
                    </td>
                    <td>
                      <a>PT. Gudang Garam</a>
                    </td>
                    <td class="project_progress">
                      <a>Motor</a>
                    </td>
                    <td>
                      <a>Sharp</a>
                    </td>
                    <td>
                      <a>Rp 7.500.000</a>
                    </td>
                    <td>
                      <!-- <a>02-01-2015</a> -->
                      <a href="#" class="btn btn-round btn-success btn-xs">02-01-2015 </a>
                    </td>
                    <td>
                      <a href="#" class="btn btn-primary btn-xs"><i class="fa fa-folder"></i> View </a>
                      <a href="#" class="btn btn-info btn-xs"><i class="fa fa-pencil"></i> Edit </a>
                    </td>
                  </tr>
                  
                </tbody>
              </table>
              <!-- end project list -->

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>