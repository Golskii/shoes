<?php

Class queries_sales extends CI_Model
{
	function autonumber($kode_terakhir, $panjang_kode, $panjang_angka)
	{
    	$kode = substr($kode_terakhir, 0, $panjang_kode);
    	$angka = substr($kode_terakhir, $panjang_kode, $panjang_angka);
    	$angka_baru = str_repeat("0", $panjang_angka - strlen($angka+1)).($angka+1);
    	$kode_baru = $kode.$angka_baru;
    	return $kode_baru;
	}

	function insert_sales($data)
	{	
		$cari_kode = 'SLS';

		$this->db->select('USER_KD');
		$this->db->like('USER_KD', $cari_kode , 'after');
		$this->db->order_by('USER_KD', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get('sw_user');
		if($query->num_rows() > 0)
		{	
			foreach ($query->result() as $key) 
			{
				$kode[] = $key;
				foreach ($kode as $simpan) 
				{
					$save['USER_KD']	 = $simpan->USER_KD;
					$save['USER_KD']	 = $this->autonumber($save['USER_KD'], 3, 4);
					$save['USER_NAMA']  = htmlspecialchars($data['fullname']);
					$save['USER_USERNAME']  = htmlspecialchars($data['username']);
					$save['USER_PASSWORD'] = htmlspecialchars($data['password']);
					$save['USER_EMAIL'] = htmlspecialchars($data['email']);
					$save['USER_ALAMAT'] = htmlspecialchars($data['alamat']);
					$save['USER_TELP']  = $data['telpon'];
					$save['USER_STATUS'] = 1;
					$save['USER_LEVEL'] = 2;
					return $this->db->insert('sw_user', $save);
				}
				
			}
		}
		else
		{
			$save['USER_KD']	 = "SLS0001";
			$save['USER_NAMA']  = htmlspecialchars($data['fullname']);
			$save['USER_USERNAME']  = htmlspecialchars($data['username']);
			$save['USER_PASSWORD'] = htmlspecialchars($data['password']);
			$save['USER_EMAIL'] = htmlspecialchars($data['email']);
			$save['USER_ALAMAT'] = htmlspecialchars($data['alamat']);
			$save['USER_TELP']  = $data['telpon'];
			$save['USER_STATUS'] = 1;
			$save['USER_LEVEL'] = 2;
			return $this->db->insert('sw_user', $save);
		}
	}

	public function get_sales()
	{
		$query = $this->db->get_where('sw_user', array('USER_STATUS' => 1, 'USER_LEVEL' => 2));
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_sales_byKD($kode)
	{
		$query = $this->db->get_where('sw_user', array('USER_KD' => $kode, 'USER_STATUS' => 1));
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_sales_byNAMA($data)
	{
		$query = $this->db->get_where('sw_user', array('USER_NAMA' => $data['USER_NAMA'], 'USER_STATUS' => 1));
		if($query -> num_rows() > 0)
		{
			// var_dump($query->result());
			// die();
			return $query->result();
		}
	}

	public function edit_sales($data){
		$this->db->where('USER_KD',$data['USER_KD']);
		return $this->db->update('sw_user', $data);
	}

	public function hapus_sales($SALES_KD){
		$this->db->where('USER_KD',$SALES_KD);
		return $this->db->update('sw_user', array('USER_STATUS' => 0 ));
	}
}

?>