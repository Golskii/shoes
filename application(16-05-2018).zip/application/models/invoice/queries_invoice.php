<?php

Class queries_invoice extends CI_Model
{
	public function autonumber($date, $catagory){
		$tahun = substr($date,2,2);
		$bulan = substr($date,5,2);
		$kategori = $catagory;
		$cari_kode = $tahun . "-" . $bulan . "-" . $kategori . "-";
		$this->db->select('PENAWARAN_KD');
		$this->db->like('PENAWARAN_KD', $cari_kode , 'after');
		$this->db->order_by('PENAWARAN_KD', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get_where('sw_penawaran');
		if($query ->num_rows() > 0)
		{	
			foreach ($query->result() as $key) 
			{
				$kode[] = $key;
				foreach ($kode as $simpan) 
				{
					$last_numb = substr($simpan->PENAWARAN_KD,9,3)+1;
					$new_numb = str_repeat("0", 2) . $last_numb;
					$save['PENAWARAN_KD'] = $cari_kode . $new_numb;
				}
			}
		}
		else
		{
			$save['PENAWARAN_KD'] = $cari_kode . "001";
		}
		return $save['PENAWARAN_KD'];
	}

	public function get_data_update($PENAWARAN_KD){
		$this->db->select('sw_perbaikan.*, sw_customer.*, sw_motor.*, sw_penawaran.*, sw_user.*, sw_workscope.*, sw_additional.*, sw_custom.*');
		$this->db->join('sw_customer', 'sw_customer.CUSTOMER_KD = sw_penawaran.CUSTOMER_KD', 'left');
		$this->db->join('sw_motor', 'sw_motor.MOTOR_KD = sw_penawaran.MOTOR_KD', 'left');
		$this->db->join('sw_user', 'sw_user.USER_KD = sw_penawaran.USER_KD', 'left');
		$this->db->join('sw_perbaikan', 'sw_perbaikan.PENAWARAN_KD = sw_penawaran.PENAWARAN_KD', 'left');
		$this->db->join('sw_workscope', 'sw_workscope.WORK_KD = sw_penawaran.WORK_KD', 'left');
		$this->db->join('sw_additional', 'sw_additional.PENAWARAN_KD = sw_penawaran.PENAWARAN_KD', 'left');
		$this->db->join('sw_custom', 'sw_custom.PENAWARAN_KD = sw_penawaran.PENAWARAN_KD', 'left');

		$this->db->where('sw_penawaran.PENAWARAN_KD', $PENAWARAN_KD);
		$result = $this->db->get('sw_penawaran');
		//echo $this->db->last_query();die();
		return $result->result();
	}

	public function get_data_update_adt($PENAWARAN_KD){
		$this->db->select('sw_custom.*');
		$this->db->join('sw_custom', 'sw_custom.PENAWARAN_KD = sw_penawaran.PENAWARAN_KD', 'left');

		$this->db->where('sw_penawaran.PENAWARAN_KD', $PENAWARAN_KD);
		$result = $this->db->get('sw_penawaran');
		//echo $this->db->last_query();die();
		return $result->result();
	}

	public function get_detail_po($PO_KD)
	{
		$this->db->select('sw_customer.*, sw_motor.*, sw_penawaran.*, sw_po.*, sw_user.*, sw_workscope.*');
		$this->db->join('sw_customer', 'sw_customer.CUSTOMER_KD = sw_penawaran.CUSTOMER_KD', 'right');
		$this->db->join('sw_motor', 'sw_motor.MOTOR_KD = sw_penawaran.MOTOR_KD', 'right');
		$this->db->join('sw_po', 'sw_po.PO_KD = sw_penawaran.PO_KD', 'right');
		$this->db->join('sw_user', 'sw_user.USER_KD = sw_penawaran.USER_KD', 'right');
		$this->db->join('sw_workscope', 'sw_workscope.WORK_KD = sw_penawaran.WORK_KD', 'right');

		$this->db->where('sw_penawaran.PO_KD', $PO_KD);
		$result = $this->db->get('sw_penawaran');
		return $result->result();

		
	}

	public function get_additional($PENAWARAN_KD)
	{
		$this->db->join('sw_additional', 'sw_additional.PENAWARAN_KD = sw_penawaran.PENAWARAN_KD');
		$this->db->join('sw_harga', 'sw_harga.HARGA_KD = sw_additional.HARGA_KD');
		$this->db->join('sw_motor', 'sw_motor.MOTOR_KD = sw_penawaran.MOTOR_KD');
		$this->db->where('sw_penawaran.PENAWARAN_KD', $PENAWARAN_KD);
		$result = $this->db->get('sw_penawaran');
		// echo "quere";
		
		return $result->result_array();
	}

	public function get_custom($PENAWARAN_KD)
	{
		$this->db->join('sw_harga', 'sw_harga.HARGA_KD = sw_custom.HARGA_KD');
		$this->db->where('sw_custom.PENAWARAN_KD', $PENAWARAN_KD);
		$result = $this->db->get('sw_custom');
		return $result->result_array();
	}

	public function get_perbaikan($PENAWARAN_KD)
	{
		$this->db->join('sw_harga', 'sw_harga.HARGA_KD = sw_perbaikan.HARGA_KD');
		$this->db->where('sw_perbaikan.PENAWARAN_KD', $PENAWARAN_KD);
		$result = $this->db->get('sw_perbaikan');
		return $result->result();
	}

	public function insert_invoice($data){
		$this->db->insert('sw_penawaran', $data);
	}
	public function update_invoice($data, $kode){
		$this->db->where('PENAWARAN_KD',$kode);
		return $this->db->update('sw_penawaran', $data);
	}

	public function insert_po($data){
		$this->db->insert('sw_po', $data);
	}

	public function get_invoice()
	{
		$query = $this->db->get('sw_penawaran');
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_invoice_byKD($PENAWARAN_KD){
		$query = $this->db->get_where('sw_penawaran', array('PENAWARAN_KD' => $PENAWARAN_KD, 'PENAWARAN_STATUS_AKTIF' => 1));
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_invoice_awal()
	{
		$query = $this->db->get_where('sw_penawaran', array('PENAWARAN_NOMINAL' => NULL, 'PENAWARAN_STATUS_AKTIF' => 1));
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_invoice_akhir()
	{
		$query = $this->db->get_where('sw_penawaran', array('PENAWARAN_NOMINAL !=' => NULL, 'PO_KD' => NULL, 'PENAWARAN_STATUS_AKTIF' => 1 ));
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_po_pending()
	{
		$this->db->join('sw_po', 'sw_penawaran.PO_KD = sw_po.PO_KD', 'left');
		$this->db->join('sw_customer', 'sw_penawaran.CUSTOMER_KD = sw_customer.CUSTOMER_KD', 'left');
		$this->db->join('sw_motor', 'sw_penawaran.MOTOR_KD = sw_motor.MOTOR_KD', 'left');
		$this->db->where(array(
			'sw_po.STATUS'=> 0  
		));
		$query = $this->db->get('sw_penawaran');
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_po_process()
	{
		$this->db->join('sw_po', 'sw_penawaran.PO_KD = sw_po.PO_KD', 'left');
		$this->db->join('sw_customer', 'sw_penawaran.CUSTOMER_KD = sw_customer.CUSTOMER_KD', 'left');
		$this->db->join('sw_motor', 'sw_penawaran.MOTOR_KD = sw_motor.MOTOR_KD', 'left');
		$this->db->where(array(
			'sw_po.STATUS'=> 1  
		));
		$query = $this->db->get('sw_penawaran');
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_po_complete()
	{
		$this->db->join('sw_po', 'sw_penawaran.PO_KD = sw_po.PO_KD', 'left');
		$this->db->join('sw_customer', 'sw_penawaran.CUSTOMER_KD = sw_customer.CUSTOMER_KD', 'left');
		$this->db->join('sw_motor', 'sw_penawaran.MOTOR_KD = sw_motor.MOTOR_KD', 'left');
		$this->db->where(array(
			'sw_po.STATUS'=> 2  
		));
		$query = $this->db->get('sw_penawaran');
		// var_dump($this->db->last_query());
		// die();
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_po_pending_byKD($PO_KD){
		$query = $this->db->get_where('sw_po', array('PO_KD' => $PO_KD, 'STATUS' => 0));
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_po_number(){
		$query = $this->db->get('sw_po');
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_last_invoice()
	{
		$this->db->select();
		$this->db->order_by('PENAWARAN_KD', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get('sw_penawaran');
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_last_po()
	{
		$this->db->select();
		$this->db->order_by('PO_KD', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get('sw_po');
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_view_list_workscope()
	{
		$query = $this->db->list_fields('sw_workscope');
		return $query;
	}

	public function update_nominal($kode,$data){
		$this->db->where('PENAWARAN_KD',$kode);
		return $this->db->update('sw_penawaran', $data);
	}

	public function update_penawaran_po($kode,$data){
		$this->db->where('PENAWARAN_KD',$kode);
		return $this->db->update('sw_penawaran', $data);
	}

	public function income_thismonth(){
		$tahun = substr(date('ym'),0,2);
		$bulan = substr(date('ym'),2,2);
		$cari_kode = $tahun . "-" . $bulan;
		$this->db->select_sum('PENAWARAN_NOMINAL');
		$this->db->like('PENAWARAN_KD', $cari_kode , 'after');
		$query = $this->db->get_where('sw_penawaran');
		if($query -> num_rows() > 0)
		{
			foreach ($query->result() as $total) {
				return $total->PENAWARAN_NOMINAL;
			}
		}
	}

	public function invoice_thismonth(){
		$tahun = substr(date('ym'),0,2);
		$bulan = substr(date('ym'),2,2);
		$cari_kode = $tahun . "-" . $bulan. "-";
		$this->db->select('PENAWARAN_KD');
		$this->db->like('PENAWARAN_KD', $cari_kode , 'after');
		$query = $this->db->get_where('sw_penawaran');
		if($query ->num_rows() > 0)
		{	
			return $query ->num_rows();
		}
	}

	public function po_thismonth(){
		$tahun = substr(date('ym'),0,2);
		$bulan = substr(date('ym'),2,2);
		$cari_kode = $tahun . "-" . $bulan. "-";
		$this->db->select('PENAWARAN_KD');
		$this->db->like('PENAWARAN_KD', $cari_kode , 'after');
		$query = $this->db->get_where('sw_penawaran', array('PO_KD !=' => NULL));
		if($query ->num_rows() > 0)
		{	
			return $query ->num_rows();
		}
	}

	public function valueable_po(){
		$this->db->join('sw_customer', 'sw_penawaran.CUSTOMER_KD = sw_customer.CUSTOMER_KD', 'left');
		$tahun = substr(date('ym'),0,2);
		$bulan = substr(date('ym'),2,2);
		$cari_kode = $tahun . "-" . $bulan. "-";
		$this->db->like('PENAWARAN_KD', $cari_kode , 'after');
		$this->db->order_by('PENAWARAN_NOMINAL', 'DESC');
		$query = $this->db->where(array(
			'PO_KD !=' => NULL, 
			'PENAWARAN_STATUS_AKTIF !=' => NULL
		));
		$query = $this->db->get('sw_penawaran');
		// var_dump($this->db->last_query());
		// var_dump($query->result());
		// die();
		if($query ->num_rows() > 0)
		{	
			return $query->result();
		}
	}

}

?>