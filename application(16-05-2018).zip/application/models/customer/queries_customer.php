<?php

Class queries_customer extends CI_Model
{
	function autonumber($kode_terakhir, $panjang_kode, $panjang_angka)
	{
    	$kode = substr($kode_terakhir, 0, $panjang_kode);
    	$angka = substr($kode_terakhir, $panjang_kode, $panjang_angka);
    	$angka_baru = str_repeat("0", $panjang_angka - strlen($angka+1)).($angka+1);
    	$kode_baru = $kode.$angka_baru;
    	return $kode_baru;
	}

	function insert_customer($data)
	{
		$this->db->select('CUSTOMER_KD');
		$this->db->order_by('CUSTOMER_KD', 'DESC');
		$this->db->limit(1);
		$query = $this->db->get('sw_customer');
		if($query->num_rows() > 0)
		{	
			foreach ($query->result() as $key) 
			{
				$kode[] = $key;
				foreach ($kode as $simpan) 
				{
					$save['CUSTOMER_KD']	 = $simpan->CUSTOMER_KD;
					$save['CUSTOMER_KD']	 = $this->autonumber($save['CUSTOMER_KD'], 3, 4);
					$save['CUSTOMER_NAMA']  = htmlspecialchars($data['username']);
					$save['CUSTOMER_EMAIL'] = htmlspecialchars($data['email']);
					$save['CUSTOMER_TELP']  = $data['telpon'];
					$save['CUSTOMER_ALAMAT'] 	= htmlspecialchars($data['alamat']);
					$save['CUSTOMER_STATUS'] = 1;
					return $this->db->insert('sw_customer', $save);
				}
				
			}
		}
		else
		{
			$save['CUSTOMER_KD'] 	= "CST0001";
			$save['CUSTOMER_NAMA']  = htmlspecialchars($data['username']);
			$save['CUSTOMER_EMAIL'] = htmlspecialchars($data['email']);
			$save['CUSTOMER_TELP']  = $data['telpon'];
			$save['CUSTOMER_ALAMAT'] 	= htmlspecialchars($data['alamat']);
			$save['CUSTOMER_STATUS'] = 1;
			return $this->db->insert('sw_customer', $save);
		}
	}

	public function get_customer()
	{
		$query = $this->db->get_where('sw_customer', array('CUSTOMER_STATUS' => 1));
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function list_customer()
	{
		$query = $this->db->get('sw_customer');
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function get_customer_byKD($kode)
	{
		$query = $this->db->get_where('sw_customer', array('CUSTOMER_KD' => $kode));
		if($query -> num_rows() > 0)
		{
			return $query->result();
		}
	}

	public function edit_customer($data){
		$this->db->where('CUSTOMER_KD',$data['CUSTOMER_KD']);
		return $this->db->update('sw_customer', $data);
	}

	public function hapus_customer($CUSTOMER_KD){
		$this->db->where('CUSTOMER_KD',$CUSTOMER_KD);
		return $this->db->update('sw_customer', array('CUSTOMER_STATUS' => 0 ));
	}

	public function customer_thismonth(){
		$tahun = substr(date('ym'),0,2);
		$bulan = substr(date('ym'),2,2);
		$cari_kode = $tahun . "-" . $bulan. "-";
		$this->db->select('CUSTOMER_KD');
		$this->db->like('PENAWARAN_KD', $cari_kode , 'after');
		$query = $this->db->get_where('sw_penawaran');
		$jumlah = 0;
		$blacklist = array();
		if($query ->num_rows() > 0)
		{	
			foreach ($query->result() as $key) {
				$a = $key->CUSTOMER_KD;
				$cek=0;
				$black = 0;
				foreach ($query->result() as $key) {
					$b = $key->CUSTOMER_KD;
					if($a == $b){
						for ($i=0; $i <= count($blacklist)-1; $i++) { 
							if($a == $blacklist[$i]){
								$black = $black + 1;
							}	
						}
						if($black == 0){
							$cek = $cek + 1;
							array_push($blacklist, $a);
						}
					}
				}
				if($cek != 0){
					$jumlah = $jumlah + 1;
				}
			}
			return $jumlah;
		}

	}
}

?>